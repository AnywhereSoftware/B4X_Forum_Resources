function applyTheme() {
    const params = new URLSearchParams(window.location.search);
    if (params.has('light-theme')) {
        const isLightTheme = params.get('light-theme') === 'true';
        const theme = isLightTheme ? 'light' : 'dark';
        localStorage.setItem('theme', theme); // Save preference
    }

    // Apply stored theme (or default to light)
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute("data-theme", savedTheme);
}

window.onload = applyTheme;