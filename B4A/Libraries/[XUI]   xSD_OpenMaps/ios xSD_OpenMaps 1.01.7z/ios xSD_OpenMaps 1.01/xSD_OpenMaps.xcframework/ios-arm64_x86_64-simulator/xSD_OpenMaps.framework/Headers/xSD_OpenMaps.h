#import <iCore/iCore.h>
#import <iHttp/iHttp.h>
#import <iNetwork/iNetwork.h>
#import <iRandomAccessFile/iRandomAccessFile.h>
#import <iXUI/iXUI.h>
#import <iJSON/iJSON.h>
#import <AVFoundation/AVFoundation.h>
@class b4i_openmaps;
@class b4i_openmapsext;
@class b4i_mapcircle;
@class b4i_maplabel;
@class b4i_mappolygon;
@class b4i_mappolyline;
@class b4i_marker;
@class b4i_latlng;
@class b4i_mapinfowindow;
@interface b4i_cameraposition : B4IClass
{
@public double __mlat;
@public double __mlng;
@public float __mzoom;

}- (NSString*)  _class_globals;
@property (nonatomic)double _mlat;
@property (nonatomic)double _mlng;
@property (nonatomic)float _mzoom;
- (double)  _getlat;
- (double)  _getlng;
- (float)  _getzoom;
- (NSString*)  _initialize:(B4I*) _ba :(double) _lat :(double) _lng :(float) _zoom;
- (NSString*)  _target;
- (NSString*)  _tostring;
@end

#import <iCore/iCore.h>
#import <iHttp/iHttp.h>
#import <iNetwork/iNetwork.h>
#import <iRandomAccessFile/iRandomAccessFile.h>
#import <iXUI/iXUI.h>
#import <iJSON/iJSON.h>
#import <AVFoundation/AVFoundation.h>
@class b4i_openmaps;
@class b4i_openmapsext;
@class b4i_mapcircle;
@class b4i_maplabel;
@class b4i_mappolygon;
@class b4i_mappolyline;
@class b4i_marker;
@class b4i_cameraposition;
@class b4i_mapinfowindow;
@interface b4i_latlng : B4IClass
{
@public double __latitude;
@public double __longitude;

}- (NSString*)  _class_globals;
@property (nonatomic)double _latitude;
@property (nonatomic)double _longitude;
- (NSString*)  _initialize:(B4I*) _ba :(double) _lat :(double) _lng;
@end

#import <iCore/iCore.h>
#import <iHttp/iHttp.h>
#import <iNetwork/iNetwork.h>
#import <iRandomAccessFile/iRandomAccessFile.h>
#import <iXUI/iXUI.h>
#import <iJSON/iJSON.h>
#import <AVFoundation/AVFoundation.h>
@class b4i_openmaps;
@class b4i_openmapsext;
@class b4i_maplabel;
@class b4i_mappolygon;
@class b4i_mappolyline;
@class b4i_marker;
@class b4i_cameraposition;
@class b4i_latlng;
@class b4i_mapinfowindow;
@interface b4i_mapcircle : B4IClass
{
@public b4i_latlng* __mcenter;
@public double __mradius;
@public BOOL __mvisible;
@public NSString* __mid;
@public B4IWebViewWrapper* __mwebview;

}- (NSString*)  _class_globals;
@property (nonatomic)b4i_latlng* _mcenter;
@property (nonatomic)double _mradius;
@property (nonatomic)BOOL _mvisible;
@property (nonatomic)NSString* _mid;
@property (nonatomic)B4IWebViewWrapper* _mwebview;
- (B4IResumableSubWrapper*)  _executejs:(NSString*) _js;
- (void)  _webview1_jscomplete:(BOOL) _success :(NSString*) _result;
- (B4IResumableSubWrapper*)  _getcenter;
- (void)  _complete:(NSString*) _result;
- (NSString*)  _getid;
- (B4IResumableSubWrapper*)  _getradius;
- (BOOL)  _getvisible;
- (NSString*)  _initialize:(B4I*) _ba :(b4i_latlng*) _vcenter :(double) _vradius :(BOOL) _visble :(NSString*) _id :(B4IWebViewWrapper*) _webview;
- (NSString*)  _setvisible:(BOOL) _b;
@end

#import <iCore/iCore.h>
#import <iHttp/iHttp.h>
#import <iNetwork/iNetwork.h>
#import <iRandomAccessFile/iRandomAccessFile.h>
#import <iXUI/iXUI.h>
#import <iJSON/iJSON.h>
#import <AVFoundation/AVFoundation.h>
@class b4i_openmaps;
@class b4i_openmapsext;
@class b4i_mapcircle;
@class b4i_maplabel;
@class b4i_mappolygon;
@class b4i_mappolyline;
@class b4i_marker;
@class b4i_cameraposition;
@class b4i_latlng;
@interface b4i_mapinfowindow : B4IClass
{
@public NSString* __mcontent;
@public b4i_latlng* __mposition;
@public NSString* __mid;

}- (NSString*)  _class_globals;
@property (nonatomic)NSString* _mcontent;
@property (nonatomic)b4i_latlng* _mposition;
@property (nonatomic)NSString* _mid;
- (NSString*)  _getcontent;
- (NSString*)  _getid;
- (b4i_latlng*)  _getposition;
- (NSString*)  _initialize:(B4I*) _ba :(NSString*) _vcontent :(b4i_latlng*) _vposition :(NSString*) _id;
@end

#import <iCore/iCore.h>
#import <iHttp/iHttp.h>
#import <iNetwork/iNetwork.h>
#import <iRandomAccessFile/iRandomAccessFile.h>
#import <iXUI/iXUI.h>
#import <iJSON/iJSON.h>
#import <AVFoundation/AVFoundation.h>
@class b4i_openmaps;
@class b4i_openmapsext;
@class b4i_mapcircle;
@class b4i_mappolygon;
@class b4i_mappolyline;
@class b4i_marker;
@class b4i_cameraposition;
@class b4i_latlng;
@class b4i_mapinfowindow;
@interface b4i_maplabel : B4IClass
{
@public B4IWebViewWrapper* __mwebview;
@public b4i_latlng* __mposition;
@public NSString* __mtext;
@public BOOL __mpermanent;
@public NSString* __mid;

}- (NSString*)  _class_globals;
@property (nonatomic)B4IWebViewWrapper* _mwebview;
@property (nonatomic)b4i_latlng* _mposition;
@property (nonatomic)NSString* _mtext;
@property (nonatomic)BOOL _mpermanent;
@property (nonatomic)NSString* _mid;
- (B4IResumableSubWrapper*)  _executejs:(NSString*) _js;
- (void)  _webview1_jscomplete:(BOOL) _success :(NSString*) _result;
- (NSString*)  _getid;
- (BOOL)  _getpermanent;
- (b4i_latlng*)  _getposition;
- (NSString*)  _gettext;
- (NSString*)  _initialize:(B4I*) _ba :(b4i_latlng*) _vposition :(NSString*) _vtext :(BOOL) _vpermanent :(NSString*) _vid :(B4IWebViewWrapper*) _webview;
- (void)  _recallid:(NSString*) _vid :(b4i_latlng*) _vposition :(BOOL) _vpermanent :(NSString*) _vtext;
- (void)  _complete:(NSString*) _id;
- (NSString*)  _settext:(NSString*) _t;
@end

#import <iCore/iCore.h>
#import <iHttp/iHttp.h>
#import <iNetwork/iNetwork.h>
#import <iRandomAccessFile/iRandomAccessFile.h>
#import <iXUI/iXUI.h>
#import <iJSON/iJSON.h>
#import <AVFoundation/AVFoundation.h>
@class b4i_openmaps;
@class b4i_openmapsext;
@class b4i_mapcircle;
@class b4i_maplabel;
@class b4i_mappolyline;
@class b4i_marker;
@class b4i_cameraposition;
@class b4i_latlng;
@class b4i_mapinfowindow;
@interface b4i_mappolygon : B4IClass
{
@public B4IXUI* __xui;
@public B4IList* __mpoint;
@public BOOL __mvisible;
@public NSString* __mid;
@public B4IWebViewWrapper* __mwebview;
@public int __mstrokewidth;
@public int __mstrokecolor;
@public int __mfillcolor;
@public double __mopacity;

}- (NSString*)  _class_globals;
@property (nonatomic)B4IXUI* _xui;
@property (nonatomic)B4IList* _mpoint;
@property (nonatomic)BOOL _mvisible;
@property (nonatomic)NSString* _mid;
@property (nonatomic)B4IWebViewWrapper* _mwebview;
@property (nonatomic)int _mstrokewidth;
@property (nonatomic)int _mstrokecolor;
@property (nonatomic)int _mfillcolor;
@property (nonatomic)double _mopacity;
- (B4IResumableSubWrapper*)  _executejs:(NSString*) _js;
- (void)  _webview1_jscomplete:(BOOL) _success :(NSString*) _result;
- (B4IResumableSubWrapper*)  _getfillcolor;
- (void)  _complete:(NSString*) _col;
- (NSString*)  _getid;
- (B4IResumableSubWrapper*)  _getlinecolor;
- (B4IResumableSubWrapper*)  _getlinewidth;
- (float)  _getopacity;
- (B4IResumableSubWrapper*)  _getpoints;
- (BOOL)  _getvisible;
- (int)  _hextocolor:(NSString*) _hex;
- (NSString*)  _initialize:(B4I*) _ba :(BOOL) _visble :(NSString*) _id :(B4IList*) _point :(int) _strokewidth :(int) _strokecolor :(int) _fillcolor :(double) _opacity :(B4IWebViewWrapper*) _webview;
- (NSString*)  _setvisible:(BOOL) _b;
@end

#import <iCore/iCore.h>
#import <iHttp/iHttp.h>
#import <iNetwork/iNetwork.h>
#import <iRandomAccessFile/iRandomAccessFile.h>
#import <iXUI/iXUI.h>
#import <iJSON/iJSON.h>
#import <AVFoundation/AVFoundation.h>
@class b4i_openmaps;
@class b4i_openmapsext;
@class b4i_mapcircle;
@class b4i_maplabel;
@class b4i_mappolygon;
@class b4i_marker;
@class b4i_cameraposition;
@class b4i_latlng;
@class b4i_mapinfowindow;
@interface b4i_mappolyline : B4IClass
{
@public B4IXUI* __xui;
@public B4IWebViewWrapper* __mwebview;
@public B4IList* __mpoint;
@public BOOL __mvisible;
@public NSString* __mid;
@public int __mstrokewidth;
@public int __mstrokecolor;

}- (NSString*)  _class_globals;
@property (nonatomic)B4IXUI* _xui;
@property (nonatomic)B4IWebViewWrapper* _mwebview;
@property (nonatomic)B4IList* _mpoint;
@property (nonatomic)BOOL _mvisible;
@property (nonatomic)NSString* _mid;
@property (nonatomic)int _mstrokewidth;
@property (nonatomic)int _mstrokecolor;
- (B4IResumableSubWrapper*)  _executejs:(NSString*) _js;
- (void)  _webview1_jscomplete:(BOOL) _success :(NSString*) _result;
- (NSString*)  _getid;
- (B4IResumableSubWrapper*)  _getlinecolor;
- (void)  _complete:(NSString*) _col;
- (B4IResumableSubWrapper*)  _getlinewidth;
- (B4IResumableSubWrapper*)  _getpoints;
- (BOOL)  _getvisible;
- (int)  _hextocolor:(NSString*) _hex;
- (NSString*)  _initialize:(B4I*) _ba :(BOOL) _visble :(NSString*) _id :(B4IList*) _point :(int) _strokewidth :(int) _strokecolor :(B4IWebViewWrapper*) _webview;
- (NSString*)  _setvisible:(BOOL) _b;
@end

#import <iCore/iCore.h>
#import <iHttp/iHttp.h>
#import <iNetwork/iNetwork.h>
#import <iRandomAccessFile/iRandomAccessFile.h>
#import <iXUI/iXUI.h>
#import <iJSON/iJSON.h>
#import <AVFoundation/AVFoundation.h>
@class b4i_openmaps;
@class b4i_openmapsext;
@class b4i_mapcircle;
@class b4i_maplabel;
@class b4i_mappolygon;
@class b4i_mappolyline;
@class b4i_cameraposition;
@class b4i_latlng;
@class b4i_mapinfowindow;
@interface b4i_marker : B4IClass
{
@public B4IWebViewWrapper* __mwebview;
@public b4i_latlng* __mposition;
@public NSString* __mtitle;
@public BOOL __mvisible;
@public NSString* __miconuri;
@public NSString* __mid;
@public BOOL __mmovible;
@public b4i_maplabel* __mlabel;

}- (NSString*)  _class_globals;
@property (nonatomic)B4IWebViewWrapper* _mwebview;
@property (nonatomic)b4i_latlng* _mposition;
@property (nonatomic)NSString* _mtitle;
@property (nonatomic)BOOL _mvisible;
@property (nonatomic)NSString* _miconuri;
@property (nonatomic)NSString* _mid;
@property (nonatomic)BOOL _mmovible;
@property (nonatomic)b4i_maplabel* _mlabel;
- (NSString*)  _createlabel:(NSString*) _text;
- (B4IResumableSubWrapper*)  _executejs:(NSString*) _js;
- (void)  _webview1_jscomplete:(BOOL) _success :(NSString*) _result;
- (NSString*)  _geticonuri;
- (B4IResumableSubWrapper*)  _geticonurl;
- (void)  _complete:(NSString*) _result;
- (NSString*)  _getid;
- (B4IResumableSubWrapper*)  _getposition;
- (B4IResumableSubWrapper*)  _gettitle;
- (BOOL)  _getvisible;
- (NSString*)  _initialize:(B4I*) _ba :(b4i_latlng*) _vposition :(NSString*) _vtitle :(NSString*) _viconuri :(BOOL) _vvisible :(NSString*) _vid :(B4IWebViewWrapper*) _webview;
- (NSString*)  _setvisible:(BOOL) _b;
- (NSString*)  _updatelabel:(NSString*) _text;
@end

#import <iCore/iCore.h>
#import <iHttp/iHttp.h>
#import <iNetwork/iNetwork.h>
#import <iRandomAccessFile/iRandomAccessFile.h>
#import <iXUI/iXUI.h>
#import <iJSON/iJSON.h>
#import <AVFoundation/AVFoundation.h>
@class b4i_openmapsext;
@class b4i_mapcircle;
@class b4i_maplabel;
@class b4i_mappolygon;
@class b4i_mappolyline;
@class b4i_marker;
@class b4i_cameraposition;
@class b4i_latlng;
@class b4i_mapinfowindow;
@interface b4i_openmaps : B4IClass
{
@public NSString* __meventname;
@public NSObject* __mcallback;
@public int __secretport;
@public B4IXUI* __xui;
@public B4XViewWrapper* __topblack;
@public B4XViewWrapper* __overlaypanel;
@public B4XViewWrapper* __mbase;
@public NSObject* __tag;
@public B4IWebViewWrapper* __webview1;
@public B4IServerSocketWrapper* __serv;
@public BOOL __work;
@public b4i_mappolygon* __epolygon;
@public b4i_mappolyline* __epolyline;
@public B4IList* __eindex;
@public b4i_mapcircle* __ecircle;
@public B4IList* __epoints;
@public b4i_latlng* __ecenter;
@public double __eradius;
@public BOOL __alternatedraw;
@public BOOL __loaded;
@public double __moffset;
@public int __mtolerance;
@public int __blackheight;
@public long long __lasttouch;
@public int __xclick;
@public int __yclick;
@public BOOL __mtouch;
@public NSString* __idediting;
@public B4IMap* __mappointedit;
@public long long __progressiveid;
@public BOOL __rdy;
@public int __map_type_hybrid;
@public int __map_type_normal;
@public int __map_type_satellite;
@public int __map_type_terrain;
@public int __map_type_esi;
@public int __map_type_carto;
@public int __map_type_esi_satellite;

}- (b4i_mapcircle*)  _addcircle:(b4i_latlng*) _ll :(double) _radius :(float) _strokewidth :(int) _strokecolor :(int) _fillcolor :(double) _opacity;
- (b4i_mapinfowindow*)  _addinfowindow:(NSString*) _content :(b4i_latlng*) _position;
- (b4i_mapinfowindow*)  _addinfowindow2:(NSString*) _content :(b4i_latlng*) _position :(int) _maxwidth;
- (b4i_marker*)  _addmarker:(double) _lat :(double) _lng :(NSString*) _title;
- (B4IResumableSubWrapper*)  _addmarker2:(double) _lat :(double) _lng :(NSString*) _title :(NSString*) _iconuri;
- (void)  _complete:(B4XBitmapWrapper*) _bm;
- (B4IResumableSubWrapper*)  _addmarker2label:(double) _lat :(double) _lng :(NSString*) _title :(NSString*) _label :(NSString*) _iconuri;
- (b4i_marker*)  _addmarker3:(double) _lat :(double) _lng :(NSString*) _title :(NSString*) _iconuri :(int) _width :(int) _height;
- (b4i_marker*)  _addmarker3bis:(double) _lat :(double) _lng :(NSString*) _title :(NSString*) _iconuri :(int) _width :(int) _height;
- (b4i_marker*)  _addmarker3label:(double) _lat :(double) _lng :(NSString*) _title :(NSString*) _label :(NSString*) _iconuri :(int) _width :(int) _height;
- (b4i_mappolygon*)  _addpolygon:(B4IList*) _points :(float) _strokewidth :(int) _strokecolor :(int) _fillcolor :(double) _opacity;
- (b4i_mappolyline*)  _addpolyline:(B4IList*) _points :(float) _strokewidth :(int) _strokecolor;
- (NSString*)  _allvisiblemapobjects;
- (NSString*)  _alternativemap:(NSString*) _url :(int) _maxzoom :(NSString*) _attribution;
- (NSString*)  _astream_newdata:(B4IArray*) _buffer;
- (NSString*)  _base_resize:(double) _width :(double) _height;
- (b4i_latlng*)  _betwen:(b4i_latlng*) _l1 :(b4i_latlng*) _l2;
- (B4IResumableSubWrapper*)  _cameraposition;
- (NSString*)  _class_globals;
@property (nonatomic)NSString* _meventname;
@property (nonatomic)NSObject* _mcallback;
@property (nonatomic)int _secretport;
@property (nonatomic)B4IXUI* _xui;
@property (nonatomic)B4XViewWrapper* _topblack;
@property (nonatomic)B4XViewWrapper* _overlaypanel;
@property (nonatomic)B4XViewWrapper* _mbase;
@property (nonatomic)NSObject* _tag;
@property (nonatomic)B4IWebViewWrapper* _webview1;
@property (nonatomic)B4IServerSocketWrapper* _serv;
@property (nonatomic)BOOL _work;
@property (nonatomic)b4i_mappolygon* _epolygon;
@property (nonatomic)b4i_mappolyline* _epolyline;
@property (nonatomic)B4IList* _eindex;
@property (nonatomic)b4i_mapcircle* _ecircle;
@property (nonatomic)B4IList* _epoints;
@property (nonatomic)b4i_latlng* _ecenter;
@property (nonatomic)double _eradius;
@property (nonatomic)BOOL _alternatedraw;
@property (nonatomic)BOOL _loaded;
@property (nonatomic)double _moffset;
@property (nonatomic)int _mtolerance;
@property (nonatomic)int _blackheight;
@property (nonatomic)long long _lasttouch;
@property (nonatomic)int _xclick;
@property (nonatomic)int _yclick;
@property (nonatomic)BOOL _mtouch;
@property (nonatomic)NSString* _idediting;
@property (nonatomic)B4IMap* _mappointedit;
@property (nonatomic)long long _progressiveid;
@property (nonatomic)BOOL _rdy;
@property (nonatomic)int _map_type_hybrid;
@property (nonatomic)int _map_type_normal;
@property (nonatomic)int _map_type_satellite;
@property (nonatomic)int _map_type_terrain;
@property (nonatomic)int _map_type_esi;
@property (nonatomic)int _map_type_carto;
@property (nonatomic)int _map_type_esi_satellite;
- (NSString*)  _clearinteredit;
- (NSString*)  _clearmap;
- (NSString*)  _clr:(int) _c;
- (NSString*)  _colortohex:(int) _color;
- (NSString*)  _designercreateview:(NSObject*) _base :(B4ILabelWrapper*) _lbl :(B4IMap*) _props;
- (NSString*)  _drawediting;
- (NSString*)  _editconfigure:(double) _offset :(int) _tollerance;
- (BOOL)  _editingactive;
- (B4IResumableSubWrapper*)  _editingcircle:(b4i_mapcircle*) _circle :(BOOL) _active;
- (B4IResumableSubWrapper*)  _editingpolygon:(b4i_mappolygon*) _polygon :(BOOL) _active;
- (B4IResumableSubWrapper*)  _editingpolyline:(b4i_mappolyline*) _polyline :(BOOL) _active;
- (B4IResumableSubWrapper*)  _executejs:(NSString*) _js;
- (void)  _webview1_jscomplete:(BOOL) _success :(NSString*) _result;
- (NSString*)  _filtervisiblemapobjects;
- (double)  _getdistance:(b4i_latlng*) _point1 :(b4i_latlng*) _point2;
- (B4IResumableSubWrapper*)  _getmapbound;
- (B4IResumableSubWrapper*)  _getnumberofelements;
- (B4IResumableSubWrapper*)  _getzoom;
- (double)  _haversinedistance:(double) _lat1 :(double) _lon1 :(double) _lat2 :(double) _lon2;
- (NSString*)  _hc_responseerror:(B4IHttpResponse*) _response :(NSString*) _reason :(int) _statuscode :(int) _taskid;
- (NSString*)  _hc_responsesuccess:(B4IHttpResponse*) _response :(int) _taskid;
- (double)  _hextoalfa:(NSString*) _hex;
- (int)  _hextocolor:(NSString*) _hex;
- (NSString*)  _html;
- (NSString*)  _initialize:(B4I*) _ba :(NSObject*) _callback :(NSString*) _eventname;
- (BOOL)  _isready;
- (B4IResumableSubWrapper*)  _latlontoxy:(b4i_latlng*) _ll;
- (void)  _listen;
- (void)  _serv_newconnection:(BOOL) _successful :(B4ISocketWrapper*) _newsocket;
- (B4IResumableSubWrapper*)  _loadimagefromurl:(NSString*) _url;
- (void)  _completejob:(BOOL) _success :(NSString*) _errormessage :(B4IHttpResponse*) _res;
- (B4IResumableSubWrapper*)  _loadmkl:(NSString*) _path :(NSString*) _filename;
- (BOOL)  _maploaded;
- (NSString*)  _messagetopanel:(NSString*) _text;
- (NSString*)  _movecamera:(b4i_cameraposition*) _cp;
- (NSString*)  _movecamera2:(b4i_latlng*) _ll;
- (BOOL)  _objectisediting:(NSString*) _idobject;
- (void)  _overlayclick:(int) _x :(int) _y;
- (void)  _overlaydrag:(int) _x :(int) _y;
- (void)  _overlaylongclick:(int) _x :(int) _y;
- (NSString*)  _overlaypanel_touch:(int) _action :(float) _x :(float) _y;
- (NSString*)  _paneloff;
- (NSString*)  _panelon;
- (NSString*)  _redrawallobj;
- (NSString*)  _removecircle:(b4i_mapcircle*) _vcircle;
- (NSString*)  _removeinfowindow:(b4i_mapinfowindow*) _infowindow;
- (NSString*)  _removemarker:(b4i_marker*) _vmarker;
- (NSString*)  _removepolygon:(b4i_mappolygon*) _vpolygon;
- (NSString*)  _removepolyline:(b4i_mappolyline*) _vpolyline;
- (void)  _savekml:(B4IMap*) _mapobj :(NSString*) _path :(NSString*) _filename;
- (void)  _setmaptype:(int) _mt;
- (NSString*)  _setzoom:(int) _z;
- (NSString*)  _subdeleteobj:(BOOL) _reset;
- (NSString*)  _timestampid;
- (NSString*)  _topblack_click;
- (NSString*)  _updatecirclecenter:(NSString*) _id :(double) _lat :(double) _lng;
- (NSString*)  _updatecircleradius:(NSString*) _id :(double) _radius;
- (NSString*)  _updatemarkerposition:(NSString*) _id :(double) _lat :(double) _lng;
- (NSString*)  _updatepolycolor:(NSString*) _id :(int) _color;
- (NSString*)  _updatepolygon:(b4i_mappolygon*) _plg :(B4IList*) _newpoints;
- (NSString*)  _updatepolygoncolor:(b4i_mappolygon*) _plg :(int) _color;
- (NSString*)  _updatepolygonfillcolor:(b4i_mappolygon*) _plg :(int) _color :(float) _opacity;
- (NSString*)  _updatepolygonstroke:(b4i_mappolygon*) _plg :(int) _width;
- (NSString*)  _updatepolyline:(b4i_mappolyline*) _pll :(B4IList*) _newpoints;
- (NSString*)  _updatepolylinecolor:(b4i_mappolyline*) _pll :(int) _color;
- (NSString*)  _updatepolylinestroke:(b4i_mappolyline*) _pll :(int) _width;
- (NSString*)  _updatepolypoint:(NSString*) _id :(B4IList*) _newpoints;
- (NSString*)  _updatepolywidth:(NSString*) _id :(int) _width;
- (NSString*)  _visibleobject:(NSString*) _id :(BOOL) _visible;
- (NSString*)  _webview1_pagefinished:(NSString*) _url;
- (B4IWebViewWrapper*)  _ww;
- (B4IResumableSubWrapper*)  _xytolatlng:(double) _x :(double) _y;
@end

#import <iCore/iCore.h>
#import <iHttp/iHttp.h>
#import <iNetwork/iNetwork.h>
#import <iRandomAccessFile/iRandomAccessFile.h>
#import <iXUI/iXUI.h>
#import <iJSON/iJSON.h>
#import <AVFoundation/AVFoundation.h>
@class b4i_openmaps;
@class b4i_mapcircle;
@class b4i_maplabel;
@class b4i_mappolygon;
@class b4i_mappolyline;
@class b4i_marker;
@class b4i_cameraposition;
@class b4i_latlng;
@class b4i_mapinfowindow;
@interface b4i_openmapsext : B4IClass
{
@public b4i_openmaps* __om;

}- (B4IResumableSubWrapper*)  _addresstolatlon:(NSString*) _address;
- (void)  _completejob:(BOOL) _success :(NSString*) _errormessage :(B4IHttpResponse*) _res;
- (B4IList*)  _bestroutetsp:(B4IList*) _points;
- (NSString*)  _class_globals;
@property (nonatomic)b4i_openmaps* _om;
- (B4IResumableSubWrapper*)  _executejs:(NSString*) _js;
- (void)  _webview1_jscomplete:(BOOL) _success :(NSString*) _result;
- (double)  _getbearing:(b4i_latlng*) _point1 :(b4i_latlng*) _point2;
- (double)  _getdistance:(b4i_latlng*) _point1 :(b4i_latlng*) _point2;
- (NSString*)  _getmarkerlabel:(b4i_marker*) _m;
- (B4IResumableSubWrapper*)  _getmarkerposition:(b4i_marker*) _m;
- (void)  _complete:(b4i_latlng*) _position;
- (B4IResumableSubWrapper*)  _getmarkertitle:(b4i_marker*) _m;
- (NSString*)  _hc_responseerror:(B4IHttpResponse*) _response :(NSString*) _reason :(int) _statuscode :(int) _taskid;
- (NSString*)  _hc_responsesuccess:(B4IHttpResponse*) _response :(int) _taskid;
- (NSString*)  _initialize:(B4I*) _ba :(b4i_openmaps*) _openmap;
- (BOOL)  _insidepath:(b4i_latlng*) _point :(B4IList*) _latlnglist;
- (B4IResumableSubWrapper*)  _latlontoaddress:(double) _lat :(double) _lon;
- (B4IResumableSubWrapper*)  _latlontoxy:(b4i_latlng*) _ll;
- (BOOL)  _objectisediting:(NSString*) _idobject;
- (B4IList*)  _optimizeroute:(B4IList*) _route;
- (NSString*)  _removemarkerlabel:(b4i_marker*) _m;
- (double)  _routedistance:(B4IList*) _route;
- (NSString*)  _setmarkerclickable:(b4i_marker*) _m :(BOOL) _clickable;
- (NSString*)  _setmarkericon:(b4i_marker*) _m :(NSString*) _url;
- (NSString*)  _setmarkerlabel:(b4i_marker*) _m :(NSString*) _text :(NSString*) _color :(double) _textsize;
- (NSString*)  _setmarkerlabel2:(b4i_marker*) _m :(NSString*) _text :(NSString*) _color :(NSString*) _backgroundcolor :(double) _textsize;
- (NSString*)  _setmarkerorigin:(b4i_marker*) _m :(double) _x :(double) _y;
- (NSString*)  _setpolygonclickable:(b4i_mappolygon*) _pg :(BOOL) _clickable;
- (B4IList*)  _twooptswap:(B4IList*) _route :(int) _i :(int) _j;
- (B4IResumableSubWrapper*)  _xytolatlng:(double) _x :(double) _y;
@end

