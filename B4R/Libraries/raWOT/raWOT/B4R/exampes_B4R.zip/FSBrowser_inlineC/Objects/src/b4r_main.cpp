#include "B4RDefines.h"

B4R::Array* b4r_main::_p_buff;
B4R::Array* b4r_main::_text;
B4R::Serial* b4r_main::_serial1;
B4R::B4RESPWiFi* b4r_main::_wifi;
B4R::ByteConverter* b4r_main::_bc;
B4R::B4RLittleFS* b4r_main::_lfs;
B4R::B4RaWOT* b4r_main::_awot;
B4R::Array* b4r_main::_buff;
bool b4r_main::_debug;
bool b4r_main::_debugf;
bool b4r_main::_traces;
b4r_globalstore* b4r_main::_globalstore;
static Byte be_gann1_4e1[0];
static B4R::Array be_gann1_4e2;
static Byte be_gann2_4e1[0];
static B4R::Array be_gann2_4e2;
static B4R::Serial be_gann3_3;
static B4R::B4RESPWiFi be_gann4_3;
static B4R::ByteConverter be_gann5_3;
static B4R::B4RLittleFS be_gann6_3;
static B4R::B4RaWOT be_gann7_3;
static Byte be_gann8_4e1[256];
static B4R::Array be_gann8_4e2;


 
#include <pgmspace.h>

const char MAIN_page[] PROGMEM = R"=====(
<!DOCTYPE html> 
<html> 
<head> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<style> 
body { 
  font-family: "Lato", sans-serif; 
} 
.main { 
  margin-left: 180px; /* Same as the width of the sidenav */ 
  padding: 0px 10px; 
} 
.active { 
  background-color: grey; 
  color: white; 
} 
.dropdown-container { 
  display: none; 
  background-color: #d1d1d1; 
  padding-left: 1px; 
} 
.fa-caret-down { 
  float: right; 
  padding-right: 8px; 
} 
@media screen and (max-height: 450px) { 
  .sidenav {padding-top: 15px;} 
  .sidenav a {font-size: 18px;} 
} 
    * { padding:0; margin:0; }  
    body { color: #333; font: 14px Sans-Serif; padding: 50px; background: #eee; }  
    h1 { text-align: center; padding: 20px 0 12px 0; margin: 0; }  
    h2 { font-size: 16px; text-align: center; padding: 0 0 12px 0; } 
    #container { box-shadow: 0 5px 10px -5px rgba(0,0,0,0.5); position: relative; background: white; }  
    table { background-color: #F3F3F3; border-collapse: collapse; width: 100%; margin: 15px 0; }  
    th { background-color: #FE4902; color: #FFF; padding: 5px 10px; }  
    th small { font-size: 9px; }  
    td, th { text-align: left; }  
    td {cursor: pointer; }  
    a { text-decoration: none; }  
    td a { color: #663300; display: block; padding: 5px 10px;  }  
    th a { padding-left: 0 }  
    th:first-of-Type { padding-left: 35px; }  
    td:Not(:first-of-Type) a { background-image: none !important; } 
    tr:nth-of-Type(odd) { background-color: #E6E6E6; }  
    tr:hover td { background-color:#CACACA; }  
    tr:hover td a { color: #000; }  
</style> 
</head> 
<body onload="getFSdata();">  
<div class="main"> 
    <h1>Directory Contents</h1> 
<div> <label><b>Current Directory : </b></label> <input Type='text' id='name0' name='name0' value='/' size='40' >  
)=====";

 const char MAIN_page1[] PROGMEM = R"=====(
 &nbsp;&nbsp;&nbsp;<label>fs Total size:</label> <label id='label1' name='label1'> 0000 </label> 
 &nbsp;&nbsp;&nbsp;<label>fs Used size:</label> <label id='label2' name='label2'> 0000 </label><div> 
<table class='sortable' id='mytable'>  
  <thead id='thead1' name='thead1'>  
    <tr> <th>Filename</th> <th>Type</th> <th>Size <small>(bytes)</small></th> <th>Date Modified</th> </tr> 
  </thead> 
  <tbody id='tbody1' name='tbody1'></tbody> 
</table>  
<label>NameOrg  </label> <input type='text' id='name1' name='name1' size='30'> 
<label>  NameNew  </label> <input type='text' id='name2' name='name2' size='30'> 
<label> Type </label> <select name='name3' id='name3'> <option value='Dir'>Dir</option> <option value='File'>File</option> </select> 
	<label>  Dir/File  </label>		
	<table class='DirActions'>
	<thead>
	  <tr>
	    <td><button onclick="mypost('DOpen')  ;" id="myButton6" style="height:30px;width:100px" class="float-left submit-button" > Dir Open  </button></td>
	    <td><button onclick="mypost('DClose')  ;" id="myButton6" style="height:30px;width:100px" class="float-left submit-button" > Dir Close  </button></td>
	    <td><button onclick="mypost('DCreate');" id="myButton5" style="height:30px;width:100px" class="float-left submit-button" > Dir Create  </button></td>
	    <td><button onclick="mypost('DDelete');" id="myButton4" style="height:30px;width:100px" class="float-left submit-button" > Dir Delete </button></td>
	    <td><button onclick="mypost('Format');" id="myButton3" style="height:30px;width:100px" class="float-left submit-button" > Eprom Format </button></td>
	  <tr>
	</thead>
	</table>
	<table class='FileActions'>
	<thead>	
      <tr>
	<form method="post" action = '/filebrowser/upload' enctype="multipart/form-data">
	<td><input onchange="myupload();" Type="file" id="file1" name="file1"/> <button style="height:30px;width:100px">File Update</button></td>
	</form>
)=====";
	
const char MAIN_page2[] PROGMEM = R"=====(
	    <td><button onclick="mypost('Download');" id="myButton2" style="height:30px;width:100px" class="float-left submit-button" >File Download</button></td>
	    <td><button onclick="mypost('Rename');"   id="myButton3" style="height:30px;width:100px" class="float-left submit-button" >File Rename </button></td>
	    <td><button onclick="mypost('Delete');"   id="myButton4" style="height:30px;width:100px" class="float-left submit-button" >File Delete </button></td>
	  <tr>
	</thead>
	</table>
</div> 
<script> 
var dropdown = document.getElementsByClassName("dropdown-btn"); 
var i; 
for (i = 0; i < dropdown.length; i++) { 
  dropdown[i].addEventListener("click", function() { 
  this.classList.toggle("active"); 
  var dropdownContent = this.nextElementSibling; 
  if (dropdownContent.style.display === "block") { 
  dropdownContent.style.display = "none"; 
  } else { 
  dropdownContent.style.display = "block"; 
  } 
  }); 
} 
function myFunction(txt) { var r = confirm(txt+' ?'); return r;  } 
function getFSdata1() {  
  document.getElementById('tbody1').innerHTML = ''; 
  getFSdata(); } 
function getFSdata() {  
  var xmlhttp = new XMLHttpRequest(); 
  xmlhttp.onreadystatechange = function() { 
    if (xmlhttp.readyState == XMLHttpRequest.DONE && xmlhttp.status == 200){  
      const parts = xmlhttp.responseText.split(String.fromCharCode(10));  
      document.getElementById('name0').value = parts[0] ;  
      document.getElementById('label1').innerHTML = parts[1] ; 
      document.getElementById('label2').innerHTML = parts[2] ; 
      var myTable = document.getElementById('mytable').getElementsByTagName('tbody')[0];  
      for (let pas = 3; pas < parts.length-6; pas++) {  
        var part = parts[pas].split("|");  
        var row = myTable.insertRow();  
        row.innerHTML=  "<tr> <td>"+part[0]+"</td> <td>"+part[1]+"</td>  <td>"+part[2]+"</td> <td>"+"01-Jan-2001 01-01"+ "</td> </tr>;"  
)=====";		 

const char MAIN_page3[] PROGMEM = R"=====(	
        row.onclick = (function(){return function(){runMe(this.innerHTML);}})(); 	
        if (parts[pas+1] == "[end]") { break;}; 
      }  
    } 
  }; 
  xmlhttp.open('POST', '/filebrowser/FSload', true); 
  xmlhttp.send(); 
} 
function myupload() {  
  const ffile = document.getElementById('file1').files[0];  
  const ffsize= (ffile.size).toString();  
  file1.name= ffsize;
  document.getElementById('file1').files[0] = "";  
}  
function runMe(text) { 
  var result = text.replace(/ /g, '');  var result1 = result.replace(/<td>/g, ''); var values = result1.split('</td>'); 
  name1.value =values[0];  
  name2.value =values[1];  
  if (name2.value !== 'Dir'){name3.value = 'File';} else {name3.value = 'Dir';} 
  name2.value ='';  
}  
function mypost(text) { 
  var xhr = new XMLHttpRequest(); 
  xhr.open('POST', '/filebrowser/action', true); 
  xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded'); 
  xhr.onload = function () { 
    getFSdata1(); 
    }; 
  xhr.send('action='+text+'&'+name1.name+'='+name1.value+'&'+name2.name+'='+name2.value+'&'+name3.name+'='+name3.value); 
  } 
function mypostX(text) {  
 var form = document.createElement('form'); form.action = '/filebrowser/download'; form.method = 'POST';  
 var input = document.createElement('input');input.type = 'hidden'; input.name = name1.name; input.value = name1.value; form.appendChild(input); 
document.body.appendChild(form); form.submit(); }  
</script> 
</body> 
</html> 
)=====";
								
const char* const msg_table[] PROGMEM = { MAIN_page,  MAIN_page1,  MAIN_page2,  MAIN_page3};
const uint16_t msg_len[] =  {sizeof(MAIN_page), sizeof(MAIN_page1), sizeof(MAIN_page2), sizeof(MAIN_page3)};
	
char strx[2000];
  
B4R::Object* gethtml(B4R::Object* o) {
	strcpy_P(strx, (char*)pgm_read_dword(&(msg_table[o->toLong()])));
	Serial.print("length_msg[");Serial.print(o->toLong());Serial.print("]= ");Serial.println(msg_len[o->toLong()]);		
    b4r_main::_text->data = strx;
    b4r_main::_text->length = msg_len[o->toLong()]-1; 
    return 0; 
}
void b4r_main::_appstart(){
const UInt cp = B4R::StackMemory::cp;
B4R::B4RString be_ann16_5;
B4R::B4RString be_ann16_7;
B4R::B4RString be_ann24_6;
B4R::B4RString be_ann27_4;
B4R::B4RString be_ann28_4;
B4R::B4RString be_ann29_4;
B4R::B4RString be_ann30_6;
B4R::B4RString be_ann31_6;
B4R::B4RString be_ann32_6;
B4R::B4RString be_ann33_6;
 //BA.debugLineNum = 23;BA.debugLine="Private Sub AppStart";
 //BA.debugLineNum = 24;BA.debugLine="Serial1.Initialize(115200)";
b4r_main::_serial1->Initialize((ULong) (115200));
 //BA.debugLineNum = 25;BA.debugLine="Log(\"AppStart\")";
B4R::Common::LogHelper(1,102,F("AppStart"));
 //BA.debugLineNum = 28;BA.debugLine="If wifi.Connect2(\"Livebox-7b06\", \"7FC5C5CF1EA7";
if (b4r_main::_wifi->Connect2(be_ann16_5.wrap("Livebox-7b06"),be_ann16_7.wrap("7FC5C5CF1EA762DFE469A36349"))) { 
 //BA.debugLineNum = 29;BA.debugLine="Log(\"Connected to network\")";
B4R::Common::LogHelper(1,102,F("Connected to network"));
 }else {
 //BA.debugLineNum = 31;BA.debugLine="Log(\"Failed to connect to network\")";
B4R::Common::LogHelper(1,102,F("Failed to connect to network"));
 };
 //BA.debugLineNum = 33;BA.debugLine="aWOT.initialize1(\"finally\",\"notfound\")";
b4r_main::_awot->initialize1(_finally,_notfound);
 //BA.debugLineNum = 34;BA.debugLine="If Not(lfs.Initialize()) Then Log(\"FS initiali";
if (Common_Not(b4r_main::_lfs->Initialize())) { 
B4R::Common::LogHelper(1,102,F("FS initialization error"));}
else {
B4R::Common::LogHelper(1,102,F("init lfs OK"));};
 //BA.debugLineNum = 35;BA.debugLine="Log(wifi.LocalIp)";
B4R::Common::LogHelper(1,101,b4r_main::_wifi->getLocalIp()->data);
 //BA.debugLineNum = 36;BA.debugLine="GlobalStore.put(0,\"/\")";
b4r_main::_globalstore->_put /*void*/ (0,(be_ann24_6.wrap("/"))->GetBytes());
 //BA.debugLineNum = 37;BA.debugLine="AddLooper(\"process\")";
B4R::__c->AddLooper(_process);
 //BA.debugLineNum = 41;BA.debugLine="aWOT.app_use1(\"m0_traces\")           ' traces";
b4r_main::_awot->app_use1(_m0_traces);
 //BA.debugLineNum = 42;BA.debugLine="aWOT.app_get(\"/\",\"m7_filebrowser\")       ' app_Ro";
b4r_main::_awot->app_get(be_ann27_4.wrap("/"),_m7_filebrowser);
 //BA.debugLineNum = 44;BA.debugLine="aWOT.app_get(\"/filebrowser\",\"m7_filebrowser\") ' a";
b4r_main::_awot->app_get(be_ann28_4.wrap("/filebrowser"),_m7_filebrowser);
 //BA.debugLineNum = 45;BA.debugLine="aWOT.app_useR(\"/filebrowser\",7) ' app_Router -";
b4r_main::_awot->app_useR(be_ann29_4.wrap("/filebrowser"),(Byte) (7));
 //BA.debugLineNum = 48;BA.debugLine="aWOT.rout_post(7,\"/action\",\"m21_filebrowser_actio";
b4r_main::_awot->rout_post((Byte) (7),be_ann30_6.wrap("/action"),_m21_filebrowser_action);
 //BA.debugLineNum = 49;BA.debugLine="aWOT.rout_post(7,\"/upload\",\"m22_FileUpload\")   '";
b4r_main::_awot->rout_post((Byte) (7),be_ann31_6.wrap("/upload"),_m22_fileupload);
 //BA.debugLineNum = 50;BA.debugLine="aWOT.rout_post(7,\"/download\",\"m23_FileDownload\")";
b4r_main::_awot->rout_post((Byte) (7),be_ann32_6.wrap("/download"),_m23_filedownload);
 //BA.debugLineNum = 51;BA.debugLine="aWOT.rout_post(7,\"/FSload\",\"m30_browserFSload\")";
b4r_main::_awot->rout_post((Byte) (7),be_ann33_6.wrap("/FSload"),_m30_browserfsload);
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
Byte b4r_main::_awotreq_read(ULong _fsize,Byte _tag){
const UInt cp = B4R::StackMemory::cp;
UInt _nbr = 0;
UInt _nbw = 0;
ULong _towrite = 0L;
ULong _temp = 0L;
 //BA.debugLineNum = 344;BA.debugLine="Sub aWOTreq_read(fsize As ULong,tag As Byte) As By";
 //BA.debugLineNum = 345;BA.debugLine="Dim nbR,nbW As UInt = 0";
_nbr = 0;
_nbw = (UInt) (0);
 //BA.debugLineNum = 346;BA.debugLine="If aWOT.req_available > 0 Then";
if (b4r_main::_awot->req_available()>0) { 
 //BA.debugLineNum = 347;BA.debugLine="nbR=aWOT.req_read1(buff)";
_nbr = (UInt) (b4r_main::_awot->req_read1(b4r_main::_buff));
 //BA.debugLineNum = 348;BA.debugLine="Dim ToWrite As ULong = fsize - lfs.Position";
_towrite = (ULong) (_fsize-b4r_main::_lfs->getPosition());
 //BA.debugLineNum = 349;BA.debugLine="If ToWrite > 0 Then";
if (_towrite>0) { 
 //BA.debugLineNum = 350;BA.debugLine="nbW=lfs.Stream.WriteBytes(buff,0,Min(nbR";
_nbw = b4r_main::_lfs->getStream()->WriteBytes(b4r_main::_buff,(UInt) (0),(UInt) (Common_Min(_nbr,_towrite)));
 }else {
 //BA.debugLineNum = 352;BA.debugLine="nbW = 0";
_nbw = (UInt) (0);
 //BA.debugLineNum = 353;BA.debugLine="tag = tag+1";
_tag = (Byte) (_tag+1);
 };
 //BA.debugLineNum = 355;BA.debugLine="If DebugF Then Log(\"aWOT read :\",nbR,\"  fi";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(4,102,F("aWOT read :"),4,_nbr,102,F("  file write :"),4,_nbw);};
 //BA.debugLineNum = 356;BA.debugLine="If DebugF Then Log(\" => req_left :\",aWOT.r";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(6,102,F(" => req_left :"),5,b4r_main::_awot->req_left(),102,F(" req_available :"),5,b4r_main::_awot->req_available(),102,F("fileposition :"),6,b4r_main::_lfs->getPosition());};
 }else {
 //BA.debugLineNum = 358;BA.debugLine="nbR = 0";
_nbr = (UInt) (0);
 //BA.debugLineNum = 359;BA.debugLine="tag = tag + 1";
_tag = (Byte) (_tag+1);
 //BA.debugLineNum = 360;BA.debugLine="If DebugF Then Log(\"Delay...\",tag)";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(2,102,F("Delay..."),1,_tag);};
 //BA.debugLineNum = 361;BA.debugLine="Dim temp As ULong = Millis";
_temp = Common_Millis();
 //BA.debugLineNum = 362;BA.debugLine="Do While (temp+250)> Millis";
while ((_temp+250)>Common_Millis()) {
 //BA.debugLineNum = 363;BA.debugLine="Delay(1)";
Common_Delay((ULong) (1));
 }
;
 };
 //BA.debugLineNum = 366;BA.debugLine="Return tag";
B4R::StackMemory::cp = cp;
Byte res22 = _tag;
if (true) return res22;
 //BA.debugLineNum = 367;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
return 0;
}
void b4r_main::_browserfsload1(B4R::B4RFile* _f){
const UInt cp = B4R::StackMemory::cp;
B4R::B4RString be_ann92_15;
Int _point = 0;
B4R::B4RString be_ann94_8;
B4R::Array* _type1 = NULL;
B4R::B4RString be_ann99_4;
B4R::B4RString be_ann101_4;
 //BA.debugLineNum = 126;BA.debugLine="Sub browserFSload1(f As File)";
 //BA.debugLineNum = 127;BA.debugLine="Dim point As Int = bc.LastIndexOf(f.Name.getby";
_point = (Int) (b4r_main::_bc->LastIndexOf(_f->getName()->GetBytes(),be_ann92_15.wrap(".")->GetBytes())+1);
 //BA.debugLineNum = 128;BA.debugLine="If f.IsDirectory Then";
if (_f->getIsDirectory()) { 
 //BA.debugLineNum = 129;BA.debugLine="Dim Type1() As Byte =\"Dir\"";
_type1 = (be_ann94_8.wrap("Dir"))->GetBytes();
 }else {
 //BA.debugLineNum = 131;BA.debugLine="Dim Type1() As Byte = (bc.SubString(f.Name";
_type1 = (b4r_main::_bc->SubString(_f->getName()->GetBytes(),(UInt) (_point)));
 };
 //BA.debugLineNum = 134;BA.debugLine="aWOT.res_print(f.Name): aWOT.res_print(\"|\"): a";
b4r_main::_awot->res_print(_f->getName());
 //BA.debugLineNum = 134;BA.debugLine="aWOT.res_print(f.Name): aWOT.res_print(\"|\"): a";
b4r_main::_awot->res_print(be_ann99_4.wrap("|"));
 //BA.debugLineNum = 134;BA.debugLine="aWOT.res_print(f.Name): aWOT.res_print(\"|\"): a";
b4r_main::_awot->res_print(b4r_main::_bc->StringFromBytes(_type1));
 //BA.debugLineNum = 134;BA.debugLine="aWOT.res_print(f.Name): aWOT.res_print(\"|\"): a";
b4r_main::_awot->res_print(be_ann101_4.wrap("|"));
 //BA.debugLineNum = 134;BA.debugLine="aWOT.res_print(f.Name): aWOT.res_print(\"|\"): a";
b4r_main::_awot->res_println(B4R::__c->NumberFormat(_f->getSize(),(Byte) (0),(Byte) (0)));
 //BA.debugLineNum = 135;BA.debugLine="If DebugF Then Log(\"stack File load=\",StackBuf";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(2,102,F("stack File load="),4,B4R::__c->StackBufferUsage());};
 //BA.debugLineNum = 136;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
UInt b4r_main::_cutheader(){
const UInt cp = B4R::StackMemory::cp;
Byte be_ann311_15e1[2];
B4R::Array be_ann311_15e2;
B4R::Array* _lf = NULL;
Byte be_ann312_13e1[1];
B4R::Array be_ann312_13e2;
B4R::Array* _chr34 = NULL;
UInt _endline1 = 0;
B4R::Array* _line1 = NULL;
UInt _endline2 = 0;
B4R::Array* _line2 = NULL;
B4R::B4RString be_ann317_11;
UInt _findex = 0;
Byte be_ann318_16e1[1];
B4R::Array be_ann318_16e2;
UInt _findex2 = 0;
B4R::B4RString be_ann319_11;
UInt _fsize1 = 0;
UInt _fsize2 = 0;
B4R::Array* _fname = NULL;
B4R::Array* _fsize = NULL;
UInt _endline3 = 0;
B4R::Array* _line3 = NULL;
UInt _endline4 = 0;
B4R::Array* _line4 = NULL;
 //BA.debugLineNum = 368;BA.debugLine="Sub cutheader() As UInt";
 //BA.debugLineNum = 369;BA.debugLine="Dim LF() As Byte = Array As Byte(13,10): Dim c";
_lf = be_ann311_15e2.create(be_ann311_15e1,2,1,(Byte) (13),(Byte) (10));
 //BA.debugLineNum = 369;BA.debugLine="Dim LF() As Byte = Array As Byte(13,10): Dim c";
_chr34 = be_ann312_13e2.create(be_ann312_13e1,1,1,(Byte) (34));
 //BA.debugLineNum = 370;BA.debugLine="Dim endline1 As UInt =bc.IndexOf(buff, LF)";
_endline1 = (UInt) (b4r_main::_bc->IndexOf(b4r_main::_buff,_lf));
 //BA.debugLineNum = 371;BA.debugLine="Dim line1() As Byte = bc.SubString2(buff,0,end";
_line1 = b4r_main::_bc->SubString2(b4r_main::_buff,(UInt) (0),_endline1);
 //BA.debugLineNum = 372;BA.debugLine="Dim endline2 As UInt =bc.IndexOf2(buff, LF,end";
_endline2 = (UInt) (b4r_main::_bc->IndexOf2(b4r_main::_buff,_lf,(UInt) (_endline1+2)));
 //BA.debugLineNum = 373;BA.debugLine="Dim line2() As Byte = bc.SubString2(buff,endli";
_line2 = b4r_main::_bc->SubString2(b4r_main::_buff,(UInt) (_endline1+2),_endline2);
 //BA.debugLineNum = 374;BA.debugLine="Dim findex As UInt =  bc.IndexOf(line2,\"filena";
_findex = (UInt) (b4r_main::_bc->IndexOf(_line2,be_ann317_11.wrap("filename=")->GetBytes()));
 //BA.debugLineNum = 375;BA.debugLine="Dim findex2 As UInt =  bc.IndexOf2(line2,Array";
_findex2 = (UInt) (b4r_main::_bc->IndexOf2(_line2,be_ann318_16e2.create(be_ann318_16e1,1,1,(Byte) (34)),(UInt) (_findex+10)));
 //BA.debugLineNum = 376;BA.debugLine="Dim fsize1 As UInt = bc.IndexOf(line2,\"name=\".";
_fsize1 = (UInt) (b4r_main::_bc->IndexOf(_line2,be_ann319_11.wrap("name=")->GetBytes()));
 //BA.debugLineNum = 377;BA.debugLine="Dim fsize2 As UInt = bc.IndexOf2(line2,chr34,";
_fsize2 = (UInt) (b4r_main::_bc->IndexOf2(_line2,_chr34,(UInt) (_fsize1+6)));
 //BA.debugLineNum = 378;BA.debugLine="Dim fname() As Byte = bc.SubString2(line2,find";
_fname = b4r_main::_bc->SubString2(_line2,(UInt) (_findex+10),_findex2);
 //BA.debugLineNum = 378;BA.debugLine="Dim fname() As Byte = bc.SubString2(line2,find";
b4r_main::_globalstore->_put /*void*/ (1,_fname);
 //BA.debugLineNum = 379;BA.debugLine="Dim fsize() As Byte = bc.SubString2(line2,fsiz";
_fsize = b4r_main::_bc->SubString2(_line2,(UInt) (_fsize1+6),_fsize2);
 //BA.debugLineNum = 379;BA.debugLine="Dim fsize() As Byte = bc.SubString2(line2,fsiz";
b4r_main::_globalstore->_put /*void*/ (2,_fsize);
 //BA.debugLineNum = 381;BA.debugLine="Dim endline3 As UInt =bc.IndexOf2(buff, LF,end";
_endline3 = (UInt) (b4r_main::_bc->IndexOf2(b4r_main::_buff,_lf,(UInt) (_endline2+2)));
 //BA.debugLineNum = 382;BA.debugLine="Dim line3() As Byte = bc.SubString2(buff,endli";
_line3 = b4r_main::_bc->SubString2(b4r_main::_buff,(UInt) (_endline2+2),_endline3);
 //BA.debugLineNum = 383;BA.debugLine="Dim endline4 As UInt =bc.IndexOf2(buff, LF,end";
_endline4 = (UInt) (b4r_main::_bc->IndexOf2(b4r_main::_buff,_lf,(UInt) (_endline3+2)));
 //BA.debugLineNum = 384;BA.debugLine="Dim line4() As Byte = bc.SubString2(buff,endli";
_line4 = b4r_main::_bc->SubString2(b4r_main::_buff,(UInt) (_endline3+2),_endline4);
 //BA.debugLineNum = 385;BA.debugLine="If Debug Then Log(\"stack=\",StackBufferUsage)";
if (b4r_main::_debug) { 
B4R::Common::LogHelper(2,102,F("stack="),4,B4R::__c->StackBufferUsage());};
 //BA.debugLineNum = 386;BA.debugLine="Return endline4+2";
B4R::StackMemory::cp = cp;
UInt res20 = (UInt) (_endline4+2);
if (true) return res20;
 //BA.debugLineNum = 387;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
return 0;
}
void b4r_main::_finally(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 447;BA.debugLine="Sub finally()";
 //BA.debugLineNum = 448;BA.debugLine="Log(\"run finally Call Back\")";
B4R::Common::LogHelper(1,102,F("run finally Call Back"));
 //BA.debugLineNum = 449;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_getdatafiles(B4R::B4RString* _fullnam,B4R::B4RString* _c_type,B4R::B4RString* _c_encoding){
const UInt cp = B4R::StackMemory::cp;
UInt _nbr = 0;
ULong _filesize = 0L;
ULong _filecurrent = 0L;
B4R::B4RString be_ann339_4;
B4R::B4RString be_ann340_4;
B4R::B4RString be_ann341_4;
B4R::B4RString be_ann341_6;
B4R::B4RString be_ann342_4;
B4R::B4RString be_ann343_4;
B4R::B4RString be_ann343_6;
 //BA.debugLineNum = 419;BA.debugLine="Sub getdatafiles(fullnam As String, c_type As Stri";
 //BA.debugLineNum = 420;BA.debugLine="If (lfs.CurrentFile.IsFile) Then lfs.close";
if ((b4r_main::_lfs->getCurrentFile()->getIsFile())) { 
b4r_main::_lfs->Close();};
 //BA.debugLineNum = 421;BA.debugLine="Log(\"fullname:\",fullnam)";
B4R::Common::LogHelper(2,102,F("fullname:"),101,_fullnam->data);
 //BA.debugLineNum = 422;BA.debugLine="Dim nbR As UInt";
_nbr = 0;
 //BA.debugLineNum = 423;BA.debugLine="If lfs.OpenRead(fullnam) Then 'file exist";
if (b4r_main::_lfs->OpenRead(_fullnam)) { 
 //BA.debugLineNum = 424;BA.debugLine="Dim filesize As ULong = lfs.CurrentFile.Si";
_filesize = b4r_main::_lfs->getCurrentFile()->getSize();
 //BA.debugLineNum = 424;BA.debugLine="Dim filesize As ULong = lfs.CurrentFile.Si";
_filecurrent = (ULong) (0);
 //BA.debugLineNum = 425;BA.debugLine="aWOT.res_set(\"Content-Type\", c_type) '\"tex";
b4r_main::_awot->res_set(be_ann339_4.wrap("Content-Type"),_c_type);
 //BA.debugLineNum = 426;BA.debugLine="aWOT.res_set(\"Content-Encoding\",c_encoding";
b4r_main::_awot->res_set(be_ann340_4.wrap("Content-Encoding"),_c_encoding);
 //BA.debugLineNum = 427;BA.debugLine="aWOT.res_set(\"Cache-Control\", \"no-cache\")";
b4r_main::_awot->res_set(be_ann341_4.wrap("Cache-Control"),be_ann341_6.wrap("no-cache"));
 //BA.debugLineNum = 428;BA.debugLine="aWOT.res_set(\"Content-Length\",  NumberForm";
b4r_main::_awot->res_set(be_ann342_4.wrap("Content-Length"),B4R::__c->NumberFormat(_filesize,(Byte) (0),(Byte) (0)));
 //BA.debugLineNum = 429;BA.debugLine="aWOT.res_set(\"Last-Modified\", \"Mon, 01 Jan";
b4r_main::_awot->res_set(be_ann343_4.wrap("Last-Modified"),be_ann343_6.wrap("Mon, 01 Jan 2525 00:00:00 GMT"));
 //BA.debugLineNum = 430;BA.debugLine="If DebugF Then Log(\"ORG: filesize=\",filesi";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(5,102,F("ORG: filesize="),6,_filesize,102,F("  file current pos = "),6,_filecurrent,102,F(Common_CRLF));};
 //BA.debugLineNum = 431;BA.debugLine="Do While filesize > filecurrent";
while (_filesize>_filecurrent) {
 //BA.debugLineNum = 432;BA.debugLine="nbR = Min(filesize-filecurrent,buff.Le";
_nbr = (UInt) (Common_Min(_filesize-_filecurrent,b4r_main::_buff->length));
 //BA.debugLineNum = 433;BA.debugLine="If DebugF Then Log(\"nb byte max to rea";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(4,102,F("nb byte max to read : "),4,_nbr,102,F(" /Nb bytes from file : "),4,b4r_main::_lfs->getStream()->ReadBytes(b4r_main::_buff,(UInt) (0),_nbr));}
else {
b4r_main::_lfs->getStream()->ReadBytes(b4r_main::_buff,(UInt) (0),_nbr);};
 //BA.debugLineNum = 434;BA.debugLine="writestream(nbR)";
_writestream(_nbr);
 //BA.debugLineNum = 435;BA.debugLine="aWOT.req_flush";
b4r_main::_awot->req_flush();
 //BA.debugLineNum = 436;BA.debugLine="filecurrent = lfs.Position";
_filecurrent = b4r_main::_lfs->getPosition();
 //BA.debugLineNum = 437;BA.debugLine="If DebugF Then Log(\"filesize = \",files";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(4,102,F("filesize = "),6,_filesize,102,F("  file current pos = "),6,_filecurrent);};
 }
;
 };
 //BA.debugLineNum = 440;BA.debugLine="lfs.Close";
b4r_main::_lfs->Close();
 //BA.debugLineNum = 441;BA.debugLine="aWOT.res_end";
b4r_main::_awot->res_end();
 //BA.debugLineNum = 442;BA.debugLine="If DebugF Then Log(\"Download End\")";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(1,102,F("Download End"));};
 //BA.debugLineNum = 444;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
B4R::B4RString* b4r_main::_getext(B4R::Array* _filename){
const UInt cp = B4R::StackMemory::cp;
Byte be_ann234_13e1[1];
B4R::Array be_ann234_13e2;
B4R::Array* _point = NULL;
B4R::Array* _ext = NULL;
 //BA.debugLineNum = 282;BA.debugLine="Sub getext(filename() As Byte) As String";
 //BA.debugLineNum = 283;BA.debugLine="Dim point() As Byte = Array As Byte(46)";
_point = be_ann234_13e2.create(be_ann234_13e1,1,1,(Byte) (46));
 //BA.debugLineNum = 284;BA.debugLine="Dim ext() As Byte = bc.SubString(filename,bc.L";
_ext = b4r_main::_bc->SubString(_filename,(UInt) (b4r_main::_bc->LastIndexOf(_filename,_point)));
 //BA.debugLineNum = 285;BA.debugLine="Return bc.StringFromBytes(ext)";
B4R::StackMemory::cp = cp;
B4R::B4RString* res3 = B4R::StackMemory::ReturnStringOnStack(b4r_main::_bc->StringFromBytes(_ext));
if (true) return res3;
 //BA.debugLineNum = 286;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
return B4R::B4RString::EMPTY;
}
B4R::B4RString* b4r_main::_getfullnam(B4R::Array* _filename){
const UInt cp = B4R::StackMemory::cp;
B4R::Array* _dir = NULL;
B4R::B4RString be_ann240_3;
B4R::Object be_ann241_14;
B4R::Object be_ann241_16;
B4R::Object* be_ann241_17e1[2];
B4R::Array be_ann241_17e2;
B4R::Array* _fullnam = NULL;
B4R::Object be_ann243_14;
B4R::B4RString be_ann243_16;
B4R::Object be_ann243_18;
B4R::Object be_ann243_20;
B4R::Object* be_ann243_21e1[3];
B4R::Array be_ann243_21e2;
B4R::Object be_ann246_8;
B4R::Object be_ann246_12;
 //BA.debugLineNum = 287;BA.debugLine="Sub getfullnam(filename() As Byte) As String";
 //BA.debugLineNum = 288;BA.debugLine="Dim dir() As Byte = GlobalStore.slot0";
_dir = b4r_main::_globalstore->_slot0 /*B4R::Array**/ ;
 //BA.debugLineNum = 289;BA.debugLine="If dir = \"/\" Then";
if ((_dir)->equals((be_ann240_3.wrap("/"))->GetBytes())) { 
 //BA.debugLineNum = 290;BA.debugLine="Dim fullnam() As Byte = JoinBytes(Array(di";
_fullnam = B4R::__c->JoinBytes(be_ann241_17e2.create(be_ann241_17e1,2,100,be_ann241_14.wrapPointer(_dir),be_ann241_16.wrapPointer(_filename)));
 }else {
 //BA.debugLineNum = 292;BA.debugLine="Dim fullnam() As Byte = JoinBytes(Array(di";
_fullnam = B4R::__c->JoinBytes(be_ann243_21e2.create(be_ann243_21e1,3,100,be_ann243_14.wrapPointer(_dir),be_ann243_18.wrapPointer(be_ann243_16.wrap("/")->GetBytes()),be_ann243_20.wrapPointer(_filename)));
 };
 //BA.debugLineNum = 294;BA.debugLine="fullnam = bc.SubString2(fullnam,0,Min(34,fulln";
_fullnam = b4r_main::_bc->SubString2(_fullnam,(UInt) (0),(UInt) (Common_Min(34,_fullnam->length)));
 //BA.debugLineNum = 295;BA.debugLine="If Debug Then Log(\"===> Fname=\",filename,\" ful";
if (b4r_main::_debug) { 
B4R::Common::LogHelper(4,102,F("===> Fname="),100,be_ann246_8.wrapPointer(_filename),102,F(" fullname = "),100,be_ann246_12.wrapPointer(_fullnam));};
 //BA.debugLineNum = 296;BA.debugLine="Return bc.StringFromBytes(fullnam)";
B4R::StackMemory::cp = cp;
B4R::B4RString* res9 = B4R::StackMemory::ReturnStringOnStack(b4r_main::_bc->StringFromBytes(_fullnam));
if (true) return res9;
 //BA.debugLineNum = 297;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
return B4R::B4RString::EMPTY;
}
void b4r_main::_m0_traces(){
const UInt cp = B4R::StackMemory::cp;
B4R::Object be_ann43_3;
B4R::Object be_ann44_1;
B4R::Object be_ann46_1;
B4R::Object be_ann48_1;
B4R::Object be_ann50_1;
B4R::Object be_ann52_1;
B4R::Object be_ann54_1;
B4R::Object be_ann56_1;
B4R::Object be_ann58_1;
B4R::Object be_ann60_1;
 //BA.debugLineNum = 64;BA.debugLine="Sub m0_traces";
 //BA.debugLineNum = 65;BA.debugLine="If traces Then";
if (b4r_main::_traces) { 
 //BA.debugLineNum = 66;BA.debugLine="Log(\" \")";
B4R::Common::LogHelper(1,102,F(" "));
 //BA.debugLineNum = 67;BA.debugLine="Log(\" ClientIP ====>\",aWOT.ClientIP)";
B4R::Common::LogHelper(2,102,F(" ClientIP ====>"),101,b4r_main::_awot->getClientIP()->data);
 //BA.debugLineNum = 69;BA.debugLine="Log(\"Trace - path received:\",aWOT.req_path";
B4R::Common::LogHelper(2,102,F("Trace - path received:"),101,b4r_main::_awot->req_path()->data);
 //BA.debugLineNum = 70;BA.debugLine="Select aWOT.req_method";
switch (B4R::BR::switchObjectToInt(10,be_ann43_3.wrapNumber((Long)b4r_main::_awot->req_method()),be_ann44_1.wrapNumber((Long)0),be_ann46_1.wrapNumber((Long)1),be_ann48_1.wrapNumber((Long)2),be_ann50_1.wrapNumber((Long)3),be_ann52_1.wrapNumber((Long)4),be_ann54_1.wrapNumber((Long)5),be_ann56_1.wrapNumber((Long)6),be_ann58_1.wrapNumber((Long)7),be_ann60_1.wrapNumber((Long)8))) {
case 0: {
 //BA.debugLineNum = 71;BA.debugLine="Case 0 :Log(\"Trace - MethodType::UNKNO";
B4R::Common::LogHelper(1,102,F("Trace - MethodType::UNKNOWN"));
 break; }
case 1: {
 //BA.debugLineNum = 72;BA.debugLine="Case 1 : Log(\"Trace - MethodType::GET\"";
B4R::Common::LogHelper(1,102,F("Trace - MethodType::GET"));
 break; }
case 2: {
 //BA.debugLineNum = 73;BA.debugLine="Case 2 : Log(\"Trace - MethodType::HEAD";
B4R::Common::LogHelper(1,102,F("Trace - MethodType::HEAD"));
 break; }
case 3: {
 //BA.debugLineNum = 74;BA.debugLine="Case 3 : Log(\"Trace - MethodType::POST";
B4R::Common::LogHelper(1,102,F("Trace - MethodType::POST"));
 break; }
case 4: {
 //BA.debugLineNum = 75;BA.debugLine="Case 4 : Log(\"Trace - MethodType::PUT\"";
B4R::Common::LogHelper(1,102,F("Trace - MethodType::PUT"));
 break; }
case 5: {
 //BA.debugLineNum = 76;BA.debugLine="Case 5 : Log(\"Trace - MethodType::DELE";
B4R::Common::LogHelper(1,102,F("Trace - MethodType::DELETE"));
 break; }
case 6: {
 //BA.debugLineNum = 77;BA.debugLine="Case 6 : Log(\"Trace - MethodType::PATC";
B4R::Common::LogHelper(1,102,F("Trace - MethodType::PATCH"));
 break; }
case 7: {
 //BA.debugLineNum = 78;BA.debugLine="Case 7 : Log(\"Trace - MethodType::OPTI";
B4R::Common::LogHelper(1,102,F("Trace - MethodType::OPTIONS"));
 break; }
case 8: {
 //BA.debugLineNum = 79;BA.debugLine="Case 8 : Log(\"Trace - MethodType::ALL\"";
B4R::Common::LogHelper(1,102,F("Trace - MethodType::ALL"));
 break; }
default: {
 //BA.debugLineNum = 80;BA.debugLine="Case Else: Log(\"Trace - method= \",";
B4R::Common::LogHelper(2,102,F("Trace - method= "),1,b4r_main::_awot->req_method());
 break; }
}
;
 };
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_m21_dirclose(B4R::B4RString* _nam1){
const UInt cp = B4R::StackMemory::cp;
B4R::B4RString be_ann168_13;
Int _i = 0;
B4R::B4RString be_ann169_32;
 //BA.debugLineNum = 207;BA.debugLine="Sub m21_DirClose(nam1 As String)";
 //BA.debugLineNum = 208;BA.debugLine="Log(\"DirClose\")";
B4R::Common::LogHelper(1,102,F("DirClose"));
 //BA.debugLineNum = 209;BA.debugLine="Dim i As Int = bc.LastIndexOf(GlobalStore.Slot";
_i = b4r_main::_bc->LastIndexOf(b4r_main::_globalstore->_slot0 /*B4R::Array**/ ,be_ann168_13.wrap("/")->GetBytes());
 //BA.debugLineNum = 210;BA.debugLine="If i > 0 Then GlobalStore.put(0,bc.SubString2(";
if (_i>0) { 
b4r_main::_globalstore->_put /*void*/ (0,b4r_main::_bc->SubString2(b4r_main::_globalstore->_slot0 /*B4R::Array**/ ,(UInt) (0),(UInt) (_i)));}
else {
b4r_main::_globalstore->_put /*void*/ (0,(be_ann169_32.wrap("/"))->GetBytes());};
 //BA.debugLineNum = 211;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_m21_dircreate(B4R::B4RString* _nam1){
const UInt cp = B4R::StackMemory::cp;
B4R::B4RString be_ann154_4;
B4R::B4RString* _fullnam = B4R::B4RString::EMPTY;
 //BA.debugLineNum = 192;BA.debugLine="Sub m21_DirCreate(nam1 As String)";
 //BA.debugLineNum = 193;BA.debugLine="Log (\"DirCreate\")";
B4R::Common::LogHelper(1,102,F("DirCreate"));
 //BA.debugLineNum = 194;BA.debugLine="If nam1 <> \"\" Then";
if ((_nam1)->equals(be_ann154_4.wrap("")) == false) { 
 //BA.debugLineNum = 195;BA.debugLine="Dim fullnam As String = getfullnam(nam1.Ge";
_fullnam = _getfullnam(_nam1->GetBytes());
 //BA.debugLineNum = 196;BA.debugLine="If  Not(lfs.Exists(fullnam)) Then lfs.MKDi";
if (Common_Not(b4r_main::_lfs->Exists(_fullnam))) { 
b4r_main::_lfs->MKDir(_fullnam);};
 };
 //BA.debugLineNum = 198;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_m21_dirdelete(B4R::B4RString* _nam1){
const UInt cp = B4R::StackMemory::cp;
B4R::B4RString be_ann146_4;
B4R::B4RString be_ann147_22;
B4R::B4RString* be_ann147_25e1[3];
B4R::Array be_ann147_25e2;
B4R::B4RString* _fullnam = B4R::B4RString::EMPTY;
 //BA.debugLineNum = 184;BA.debugLine="Sub m21_DirDelete(nam1 As String)";
 //BA.debugLineNum = 185;BA.debugLine="Log (\"DirDelete\")";
B4R::Common::LogHelper(1,102,F("DirDelete"));
 //BA.debugLineNum = 186;BA.debugLine="If nam1 <> \"\" Then";
if ((_nam1)->equals(be_ann146_4.wrap("")) == false) { 
 //BA.debugLineNum = 187;BA.debugLine="Dim fullnam As String = JoinStrings(Array As";
_fullnam = B4R::__c->JoinStrings(be_ann147_25e2.create(be_ann147_25e1,3,100,b4r_main::_bc->StringFromBytes(b4r_main::_globalstore->_slot0 /*B4R::Array**/ ),be_ann147_22.wrap("/"),_nam1));
 //BA.debugLineNum = 188;BA.debugLine="If DebugF Then Log(\"fullnam=\",fullnam)";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(2,102,F("fullnam="),101,_fullnam->data);};
 //BA.debugLineNum = 189;BA.debugLine="If  lfs.Exists( fullnam) Then lfs.RMDir(fu";
if (b4r_main::_lfs->Exists(_fullnam)) { 
b4r_main::_lfs->RMDir(_fullnam);};
 };
 //BA.debugLineNum = 191;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_m21_diropen(B4R::B4RString* _nam1){
const UInt cp = B4R::StackMemory::cp;
B4R::B4RString be_ann161_4;
B4R::B4RString* _fullnam = B4R::B4RString::EMPTY;
B4R::B4RString be_ann163_26;
 //BA.debugLineNum = 200;BA.debugLine="Sub m21_DirOpen(nam1 As String)";
 //BA.debugLineNum = 201;BA.debugLine="Log (\"DirOpen\")";
B4R::Common::LogHelper(1,102,F("DirOpen"));
 //BA.debugLineNum = 202;BA.debugLine="If nam1 <> \"\" Then";
if ((_nam1)->equals(be_ann161_4.wrap("")) == false) { 
 //BA.debugLineNum = 203;BA.debugLine="Dim fullnam As String = getfullnam(nam1.GetB";
_fullnam = _getfullnam(_nam1->GetBytes());
 //BA.debugLineNum = 204;BA.debugLine="If  lfs.Exists( fullnam) Then GlobalStore.Pu";
if (b4r_main::_lfs->Exists(_fullnam)) { 
b4r_main::_globalstore->_put /*void*/ (0,_fullnam->GetBytes());}
else {
b4r_main::_globalstore->_put /*void*/ (0,(be_ann163_26.wrap("/"))->GetBytes());};
 };
 //BA.debugLineNum = 206;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_m21_filebrowser_action(){
const UInt cp = B4R::StackMemory::cp;
Byte be_ann107_4e1[20];
B4R::Array be_ann107_4e2;
B4R::Array* _name = NULL;
Byte be_ann108_4e1[20];
B4R::Array be_ann108_4e2;
B4R::Array* _value = NULL;
B4R::B4RString* _act = B4R::B4RString::EMPTY;
B4R::B4RString* _nam1 = B4R::B4RString::EMPTY;
B4R::B4RString* _nam2 = B4R::B4RString::EMPTY;
B4R::B4RString* _typ = B4R::B4RString::EMPTY;
B4R::Object be_ann121_1;
B4R::Object be_ann122_1;
B4R::Object be_ann124_1;
B4R::Object be_ann126_1;
B4R::Object be_ann128_1;
B4R::Object be_ann130_1;
B4R::Object be_ann132_1;
B4R::Object be_ann134_1;
B4R::B4RString be_ann123_4;
B4R::B4RString be_ann125_4;
B4R::B4RString be_ann129_4;
B4R::B4RString be_ann131_4;
B4R::B4RString be_ann133_5;
 //BA.debugLineNum = 137;BA.debugLine="Sub m21_filebrowser_action";
 //BA.debugLineNum = 138;BA.debugLine="If Debug Then Log(\"filebrowser -> action\")";
if (b4r_main::_debug) { 
B4R::Common::LogHelper(1,102,F("filebrowser -> action"));};
 //BA.debugLineNum = 140;BA.debugLine="Dim name(20) As Byte";
_name =be_ann107_4e2.wrap(be_ann107_4e1,20);
 //BA.debugLineNum = 141;BA.debugLine="Dim value(20) As Byte";
_value =be_ann108_4e2.wrap(be_ann108_4e1,20);
 //BA.debugLineNum = 142;BA.debugLine="aWOT.req_form(name, value)";
b4r_main::_awot->req_form(_name,_value);
 //BA.debugLineNum = 144;BA.debugLine="Dim act As String = bc.StringFromBytes(bc.Trim";
_act = b4r_main::_bc->StringFromBytes(b4r_main::_bc->Trim(_value));
 //BA.debugLineNum = 145;BA.debugLine="If Debug Then Log(\"act -> \",act)";
if (b4r_main::_debug) { 
B4R::Common::LogHelper(2,102,F("act -> "),101,_act->data);};
 //BA.debugLineNum = 146;BA.debugLine="aWOT.req_form(name, value)";
b4r_main::_awot->req_form(_name,_value);
 //BA.debugLineNum = 148;BA.debugLine="Dim nam1 As String = bc.StringFromBytes(bc.Tri";
_nam1 = b4r_main::_bc->StringFromBytes(b4r_main::_bc->Trim(_value));
 //BA.debugLineNum = 149;BA.debugLine="If Debug Then Log(\"nam1 -> \",nam1)";
if (b4r_main::_debug) { 
B4R::Common::LogHelper(2,102,F("nam1 -> "),101,_nam1->data);};
 //BA.debugLineNum = 150;BA.debugLine="aWOT.req_form(name, value)";
b4r_main::_awot->req_form(_name,_value);
 //BA.debugLineNum = 151;BA.debugLine="Dim nam2 As String = bc.StringFromBytes(bc.Tri";
_nam2 = b4r_main::_bc->StringFromBytes(b4r_main::_bc->Trim(_value));
 //BA.debugLineNum = 152;BA.debugLine="If Debug Then Log(\"nam2 -> \",nam2)";
if (b4r_main::_debug) { 
B4R::Common::LogHelper(2,102,F("nam2 -> "),101,_nam2->data);};
 //BA.debugLineNum = 153;BA.debugLine="aWOT.req_form(name, value)";
b4r_main::_awot->req_form(_name,_value);
 //BA.debugLineNum = 154;BA.debugLine="Dim typ As String = bc.StringFromBytes(bc.Trim";
_typ = b4r_main::_bc->StringFromBytes(b4r_main::_bc->Trim(_value));
 //BA.debugLineNum = 155;BA.debugLine="If Debug Then Log(\"typ -> \",typ)";
if (b4r_main::_debug) { 
B4R::Common::LogHelper(2,102,F("typ -> "),101,_typ->data);};
 //BA.debugLineNum = 156;BA.debugLine="Select act";
switch (B4R::BR::switchObjectToInt(8,be_ann121_1.wrapPointer(_act->data),be_ann122_1.wrapPointer("DCreate"),be_ann124_1.wrapPointer("DOpen"),be_ann126_1.wrapPointer("DClose"),be_ann128_1.wrapPointer("DDelete"),be_ann130_1.wrapPointer("Delete"),be_ann132_1.wrapPointer("Rename"),be_ann134_1.wrapPointer("Format"))) {
case 0: {
 //BA.debugLineNum = 158;BA.debugLine="If typ = \"Dir\" Then m21_DirCreate(nam1";
if ((_typ)->equals(be_ann123_4.wrap("Dir"))) { 
_m21_dircreate(_nam1);};
 break; }
case 1: {
 //BA.debugLineNum = 160;BA.debugLine="If typ = \"Dir\" Then m21_DirOpen(nam1)";
if ((_typ)->equals(be_ann125_4.wrap("Dir"))) { 
_m21_diropen(_nam1);};
 break; }
case 2: {
 //BA.debugLineNum = 162;BA.debugLine="m21_DirClose(nam1)";
_m21_dirclose(_nam1);
 break; }
case 3: {
 //BA.debugLineNum = 164;BA.debugLine="If typ = \"Dir\" Then m21_DirDelete(nam1";
if ((_typ)->equals(be_ann129_4.wrap("Dir"))) { 
_m21_dirdelete(_nam1);};
 break; }
case 4: {
 //BA.debugLineNum = 166;BA.debugLine="If typ = \"File\" Then m21_FileDelete(na";
if ((_typ)->equals(be_ann131_4.wrap("File"))) { 
_m21_filedelete(_nam1);};
 break; }
case 5: {
 //BA.debugLineNum = 168;BA.debugLine="If typ <> \"Dir\" Then m21_FileRename(na";
if ((_typ)->equals(be_ann133_5.wrap("Dir")) == false) { 
_m21_filerename(_nam1,_nam2);};
 break; }
case 6: {
 //BA.debugLineNum = 170;BA.debugLine="m21_Format";
_m21_format();
 break; }
}
;
 //BA.debugLineNum = 176;BA.debugLine="aWOT.res_sendStatus(200)";
b4r_main::_awot->res_sendStatus(200);
 //BA.debugLineNum = 177;BA.debugLine="If Debug Then Log(\"stack=\",StackBufferUsage)";
if (b4r_main::_debug) { 
B4R::Common::LogHelper(2,102,F("stack="),4,B4R::__c->StackBufferUsage());};
 //BA.debugLineNum = 178;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_m21_filedelete(B4R::B4RString* _nam1){
const UInt cp = B4R::StackMemory::cp;
B4R::B4RString* _fullnam = B4R::B4RString::EMPTY;
 //BA.debugLineNum = 212;BA.debugLine="Sub m21_FileDelete(nam1 As String)";
 //BA.debugLineNum = 213;BA.debugLine="Log(\"FileDelete\")";
B4R::Common::LogHelper(1,102,F("FileDelete"));
 //BA.debugLineNum = 214;BA.debugLine="Dim fullnam As String = getfullnam(nam1.GetByt";
_fullnam = _getfullnam(_nam1->GetBytes());
 //BA.debugLineNum = 215;BA.debugLine="If  lfs.Exists(fullnam) Then lfs.Remove(fullna";
if (b4r_main::_lfs->Exists(_fullnam)) { 
b4r_main::_lfs->Remove(_fullnam);};
 //BA.debugLineNum = 216;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_m21_filerename(B4R::B4RString* _nam1,B4R::B4RString* _nam2){
const UInt cp = B4R::StackMemory::cp;
B4R::B4RString be_ann178_5;
B4R::B4RString be_ann178_12;
B4R::B4RString* _fullnam1 = B4R::B4RString::EMPTY;
B4R::B4RString* _fullnam2 = B4R::B4RString::EMPTY;
 //BA.debugLineNum = 217;BA.debugLine="Sub m21_FileRename(nam1 As String,nam2 As String)";
 //BA.debugLineNum = 218;BA.debugLine="Log(\"FileRename\")";
B4R::Common::LogHelper(1,102,F("FileRename"));
 //BA.debugLineNum = 219;BA.debugLine="If (nam1 <> \"\") And (nam2<>\"\") Then";
if (((_nam1)->equals(be_ann178_5.wrap("")) == false) && ((_nam2)->equals(be_ann178_12.wrap("")) == false)) { 
 //BA.debugLineNum = 220;BA.debugLine="Dim fullnam1 As String = getfullnam(nam1.G";
_fullnam1 = _getfullnam(_nam1->GetBytes());
 //BA.debugLineNum = 221;BA.debugLine="Dim fullnam2 As String = getfullnam(nam2.G";
_fullnam2 = _getfullnam(_nam2->GetBytes());
 //BA.debugLineNum = 222;BA.debugLine="If  lfs.Exists( fullnam1) Then lfs.Rename(";
if (b4r_main::_lfs->Exists(_fullnam1)) { 
b4r_main::_lfs->Rename(_fullnam1,_fullnam2);};
 };
 //BA.debugLineNum = 224;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_m21_format(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 179;BA.debugLine="Sub m21_Format";
 //BA.debugLineNum = 180;BA.debugLine="Log (\"Eeprom Format\")";
B4R::Common::LogHelper(1,102,F("Eeprom Format"));
 //BA.debugLineNum = 182;BA.debugLine="lfs.Format";
b4r_main::_lfs->Format();
 //BA.debugLineNum = 183;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_m22_fileupload(){
const UInt cp = B4R::StackMemory::cp;
UInt _endheader = 0;
UInt _nbr = 0;
ULong _fsize = 0L;
B4R::B4RString* _fullnam = B4R::B4RString::EMPTY;
UInt _nbw = 0;
UInt _tag = 0;
B4R::B4RString be_ann277_4;
B4R::B4RString be_ann277_6;
 //BA.debugLineNum = 300;BA.debugLine="Sub m22_FileUpload";
 //BA.debugLineNum = 301;BA.debugLine="Log(\"File Upload\"):";
B4R::Common::LogHelper(1,102,F("File Upload"));
 //BA.debugLineNum = 302;BA.debugLine="If (lfs.CurrentFile.IsFile) Then lfs.close";
if ((b4r_main::_lfs->getCurrentFile()->getIsFile())) { 
b4r_main::_lfs->Close();};
 //BA.debugLineNum = 305;BA.debugLine="Dim endheader As UInt = 0";
_endheader = (UInt) (0);
 //BA.debugLineNum = 306;BA.debugLine="If DebugF Then Log(\"=> req_left Start:\",aWOT.r";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(4,102,F("=> req_left Start:"),5,b4r_main::_awot->req_left(),102,F(" req_available Start:"),5,b4r_main::_awot->req_available());};
 //BA.debugLineNum = 307;BA.debugLine="Dim nbR As UInt =aWOT.req_read1(buff)";
_nbr = (UInt) (b4r_main::_awot->req_read1(b4r_main::_buff));
 //BA.debugLineNum = 308;BA.debugLine="Dim endheader As UInt = cutheader";
_endheader = _cutheader();
 //BA.debugLineNum = 309;BA.debugLine="If DebugF Then Log(\"first nb read=stream\",nbR,";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(4,102,F("first nb read=stream"),4,_nbr,102,F(" endheader size="),4,_endheader);};
 //BA.debugLineNum = 311;BA.debugLine="Dim fsize As ULong = Bit.ParseInt(bc.StringFro";
_fsize = (ULong) (BitClass_ParseInt(b4r_main::_bc->StringFromBytes(b4r_main::_globalstore->_slot2 /*B4R::Array**/ ),(Byte) (10)));
 //BA.debugLineNum = 311;BA.debugLine="Dim fsize As ULong = Bit.ParseInt(bc.StringFro";
B4R::Common::LogHelper(2,102,F(" Fsize="),6,_fsize);
 //BA.debugLineNum = 312;BA.debugLine="Dim fullnam As String = getfullnam(GlobalStore";
_fullnam = _getfullnam(b4r_main::_globalstore->_slot1 /*B4R::Array**/ );
 //BA.debugLineNum = 313;BA.debugLine="If fsize < (lfs.TotalSize-lfs.UsedSize) Then";
if (_fsize<(b4r_main::_lfs->getTotalSize()-b4r_main::_lfs->getUsedSize())) { 
 //BA.debugLineNum = 315;BA.debugLine="If (lfs.OpenReadWrite(bc.StringFromBytes(ful";
if ((b4r_main::_lfs->OpenReadWrite(b4r_main::_bc->StringFromBytes((_fullnam)->GetBytes()))==Common_False)) { 
 //BA.debugLineNum = 316;BA.debugLine="If DebugF Then Log(\"error openning \", full";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(2,102,F("error openning "),101,_fullnam->data);};
 //BA.debugLineNum = 317;BA.debugLine="If DebugF Then Log(\"error Update\")";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(1,102,F("error Update"));};
 }else {
 //BA.debugLineNum = 319;BA.debugLine="If DebugF Then Log(\"file open :\",lfs.Cur";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(2,102,F("file open :"),101,b4r_main::_lfs->getCurrentFile()->getName()->data);};
 //BA.debugLineNum = 320;BA.debugLine="Dim nbW As UInt = lfs.Stream.WriteBytes(";
_nbw = b4r_main::_lfs->getStream()->WriteBytes(b4r_main::_buff,_endheader,(UInt) (Common_Min(_nbr-_endheader,_fsize)));
 //BA.debugLineNum = 321;BA.debugLine="If DebugF Then Log(\"aWOT read :\",nbR,\"";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(4,102,F("aWOT read :"),4,_nbr,102,F("  file write :"),4,_nbw);};
 //BA.debugLineNum = 323;BA.debugLine="Dim tag As UInt =0";
_tag = (UInt) (0);
 //BA.debugLineNum = 324;BA.debugLine="Do While (aWOT.req_left > 0)And (tag <10";
while ((b4r_main::_awot->req_left()>0) && (_tag<10)) {
 //BA.debugLineNum = 325;BA.debugLine="tag = aWOTreq_read(fsize,tag)";
_tag = (UInt) (_awotreq_read(_fsize,(Byte) (_tag)));
 }
;
 //BA.debugLineNum = 327;BA.debugLine="If tag =10 Then Log(\"timeout reading aWO";
if (_tag==10) { 
B4R::Common::LogHelper(1,102,F("timeout reading aWOT stream"));};
 //BA.debugLineNum = 328;BA.debugLine="If DebugF Then Log(\"Write End\")";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(1,102,F("Write End"));};
 //BA.debugLineNum = 329;BA.debugLine="lfs.Close";
b4r_main::_lfs->Close();
 //BA.debugLineNum = 330;BA.debugLine="If DebugF Then Log(\"file Closed\")";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(1,102,F("file Closed"));};
 //BA.debugLineNum = 331;BA.debugLine="If DebugF Then Log(\"=> req_left End:\",";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(4,102,F("=> req_left End:"),5,b4r_main::_awot->req_left(),102,F(" req_available End:"),5,b4r_main::_awot->req_available());};
 //BA.debugLineNum = 334;BA.debugLine="aWOT.res_set(\"Location\", \"/\")";
b4r_main::_awot->res_set(be_ann277_4.wrap("Location"),be_ann277_6.wrap("/"));
 //BA.debugLineNum = 335;BA.debugLine="aWOT.res_sendStatus(302)";
b4r_main::_awot->res_sendStatus(302);
 //BA.debugLineNum = 337;BA.debugLine="If DebugF Then Log(\"Update End\")";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(1,102,F("Update End"));};
 };
 }else {
 //BA.debugLineNum = 340;BA.debugLine="If DebugF Then Log(\"file too large, updat";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(1,102,F("file too large, update abort"));};
 };
 //BA.debugLineNum = 342;BA.debugLine="If Debug Then Log(\"stack=\",StackBufferUsage)";
if (b4r_main::_debug) { 
B4R::Common::LogHelper(2,102,F("stack="),4,B4R::__c->StackBufferUsage());};
 //BA.debugLineNum = 343;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_m23_file_download(B4R::B4RString* _filename){
const UInt cp = B4R::StackMemory::cp;
B4R::B4RString* _fullnam = B4R::B4RString::EMPTY;
UInt _nbr = 0;
ULong _filesize = 0L;
ULong _filecurrent = 0L;
B4R::B4RString be_ann203_4;
B4R::B4RString be_ann203_6;
B4R::B4RString be_ann204_4;
B4R::B4RString be_ann204_6;
B4R::B4RString be_ann205_4;
B4R::B4RString be_ann206_4;
B4R::B4RString be_ann206_6;
B4R::B4RString be_ann207_13;
B4R::B4RString* be_ann207_21e1[2];
B4R::Array be_ann207_21e2;
B4R::B4RString* _attach = B4R::B4RString::EMPTY;
B4R::B4RString be_ann208_4;
B4R::B4RString be_ann209_10;
B4R::B4RString* be_ann209_13e1[2];
B4R::Array be_ann209_13e2;
B4R::B4RString be_ann210_4;
 //BA.debugLineNum = 242;BA.debugLine="Sub m23_File_Download(filename As String)";
 //BA.debugLineNum = 243;BA.debugLine="If (lfs.CurrentFile.IsFile) Then lfs.close";
if ((b4r_main::_lfs->getCurrentFile()->getIsFile())) { 
b4r_main::_lfs->Close();};
 //BA.debugLineNum = 245;BA.debugLine="Dim fullnam As String = getfullnam(filename.ge";
_fullnam = _getfullnam(_filename->GetBytes());
 //BA.debugLineNum = 246;BA.debugLine="Dim nbR As UInt";
_nbr = 0;
 //BA.debugLineNum = 247;BA.debugLine="If lfs.OpenRead(fullnam) Then 'file exist";
if (b4r_main::_lfs->OpenRead(_fullnam)) { 
 //BA.debugLineNum = 248;BA.debugLine="Dim filesize As ULong = lfs.CurrentFile.Si";
_filesize = b4r_main::_lfs->getCurrentFile()->getSize();
 //BA.debugLineNum = 248;BA.debugLine="Dim filesize As ULong = lfs.CurrentFile.Si";
_filecurrent = (ULong) (0);
 //BA.debugLineNum = 249;BA.debugLine="aWOT.res_set(\"Content-Transfer-Encoding\",";
b4r_main::_awot->res_set(be_ann203_4.wrap("Content-Transfer-Encoding"),be_ann203_6.wrap("binary"));
 //BA.debugLineNum = 250;BA.debugLine="aWOT.res_set(\"Accept-Ranges\",\"bytes\")";
b4r_main::_awot->res_set(be_ann204_4.wrap("Accept-Ranges"),be_ann204_6.wrap("bytes"));
 //BA.debugLineNum = 251;BA.debugLine="aWOT.res_set(\"Content-Length\", NumberForma";
b4r_main::_awot->res_set(be_ann205_4.wrap("Content-Length"),B4R::__c->NumberFormat(_filesize,(Byte) (0),(Byte) (0)));
 //BA.debugLineNum = 252;BA.debugLine="aWOT.res_set(\"Content-Encoding\",\"none\")";
b4r_main::_awot->res_set(be_ann206_4.wrap("Content-Encoding"),be_ann206_6.wrap("none"));
 //BA.debugLineNum = 253;BA.debugLine="Dim attach As String =JoinStrings(Array As";
_attach = B4R::__c->JoinStrings(be_ann207_21e2.create(be_ann207_21e1,2,100,be_ann207_13.wrap("application/"),_getext(_filename->GetBytes())));
 //BA.debugLineNum = 254;BA.debugLine="aWOT.res_set(\"Content-Type\",attach)";
b4r_main::_awot->res_set(be_ann208_4.wrap("Content-Type"),_attach);
 //BA.debugLineNum = 255;BA.debugLine="attach = JoinStrings(Array As String(\"atta";
_attach = B4R::__c->JoinStrings(be_ann209_13e2.create(be_ann209_13e1,2,100,be_ann209_10.wrap("attachment; filename="),_filename));
 //BA.debugLineNum = 256;BA.debugLine="aWOT.res_set(\"Content-Disposition\",attach";
b4r_main::_awot->res_set(be_ann210_4.wrap("Content-Disposition"),_attach);
 //BA.debugLineNum = 258;BA.debugLine="If DebugF Then Log(\"ORG: filesize=\",filesi";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(5,102,F("ORG: filesize="),6,_filesize,102,F("  file current pos = "),6,_filecurrent,102,F(Common_CRLF));};
 //BA.debugLineNum = 259;BA.debugLine="Do While filesize > filecurrent";
while (_filesize>_filecurrent) {
 //BA.debugLineNum = 260;BA.debugLine="nbR = Min(filesize-filecurrent,buff.Le";
_nbr = (UInt) (Common_Min(_filesize-_filecurrent,b4r_main::_buff->length));
 //BA.debugLineNum = 261;BA.debugLine="If DebugF Then Log(\"nb byte max to rea";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(4,102,F("nb byte max to read : "),4,_nbr,102,F(" /Nb bytes from file : "),4,b4r_main::_lfs->getStream()->ReadBytes(b4r_main::_buff,(UInt) (0),_nbr));}
else {
b4r_main::_lfs->getStream()->ReadBytes(b4r_main::_buff,(UInt) (0),_nbr);};
 //BA.debugLineNum = 262;BA.debugLine="writestream(nbR)";
_writestream(_nbr);
 //BA.debugLineNum = 263;BA.debugLine="aWOT.req_flush";
b4r_main::_awot->req_flush();
 //BA.debugLineNum = 264;BA.debugLine="filecurrent = lfs.Position";
_filecurrent = b4r_main::_lfs->getPosition();
 //BA.debugLineNum = 265;BA.debugLine="If DebugF Then Log(\"filesize = \",files";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(4,102,F("filesize = "),6,_filesize,102,F("  file current pos = "),6,_filecurrent);};
 }
;
 };
 //BA.debugLineNum = 268;BA.debugLine="lfs.Close";
b4r_main::_lfs->Close();
 //BA.debugLineNum = 269;BA.debugLine="aWOT.res_end";
b4r_main::_awot->res_end();
 //BA.debugLineNum = 270;BA.debugLine="If DebugF Then Log(\"Download End\")";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(1,102,F("Download End"));};
 //BA.debugLineNum = 271;BA.debugLine="If Debug Then Log(\"stack=\",StackBufferUsage)";
if (b4r_main::_debug) { 
B4R::Common::LogHelper(2,102,F("stack="),4,B4R::__c->StackBufferUsage());};
 //BA.debugLineNum = 272;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_m23_filedownload(){
const UInt cp = B4R::StackMemory::cp;
Byte be_ann186_4e1[20];
B4R::Array be_ann186_4e2;
B4R::Array* _name = NULL;
Byte be_ann187_4e1[20];
B4R::Array be_ann187_4e2;
B4R::Array* _value = NULL;
B4R::B4RString* _value1 = B4R::B4RString::EMPTY;
B4R::B4RString be_ann192_4;
B4R::B4RString be_ann192_6;
 //BA.debugLineNum = 227;BA.debugLine="Sub m23_FileDownload";
 //BA.debugLineNum = 228;BA.debugLine="If Debug Then Log(\"filebrowser -> download\")";
if (b4r_main::_debug) { 
B4R::Common::LogHelper(1,102,F("filebrowser -> download"));};
 //BA.debugLineNum = 230;BA.debugLine="Dim name(20) As Byte";
_name =be_ann186_4e2.wrap(be_ann186_4e1,20);
 //BA.debugLineNum = 231;BA.debugLine="Dim value(20) As Byte";
_value =be_ann187_4e2.wrap(be_ann187_4e1,20);
 //BA.debugLineNum = 232;BA.debugLine="aWOT.req_form(name, value)";
b4r_main::_awot->req_form(_name,_value);
 //BA.debugLineNum = 234;BA.debugLine="Dim value1 As String = bc.StringFromBytes(bc.T";
_value1 = b4r_main::_bc->StringFromBytes(b4r_main::_bc->Trim(_value));
 //BA.debugLineNum = 235;BA.debugLine="If Debug Then Log(\"file -> \",value1)";
if (b4r_main::_debug) { 
B4R::Common::LogHelper(2,102,F("file -> "),101,_value1->data);};
 //BA.debugLineNum = 236;BA.debugLine="m23_File_Download(value1)";
_m23_file_download(_value1);
 //BA.debugLineNum = 237;BA.debugLine="aWOT.res_set(\"Location\", \"/\")";
b4r_main::_awot->res_set(be_ann192_4.wrap("Location"),be_ann192_6.wrap("/"));
 //BA.debugLineNum = 238;BA.debugLine="aWOT.res_sendStatus(302)";
b4r_main::_awot->res_sendStatus(302);
 //BA.debugLineNum = 240;BA.debugLine="If Debug Then Log(\"stack=\",StackBufferUsage)";
if (b4r_main::_debug) { 
B4R::Common::LogHelper(2,102,F("stack="),4,B4R::__c->StackBufferUsage());};
 //BA.debugLineNum = 241;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_m30_browserfsload(){
const UInt cp = B4R::StackMemory::cp;
B4R::B4RString be_ann79_4;
B4R::B4RString be_ann79_6;
B4R::B4RString be_ann80_4;
B4R::B4RString be_ann80_6;
B4R::B4RFile* _f = NULL;
 //BA.debugLineNum = 110;BA.debugLine="Sub m30_browserFSload";
 //BA.debugLineNum = 111;BA.debugLine="Log(\"Filebrowser -> getFSdata\")";
B4R::Common::LogHelper(1,102,F("Filebrowser -> getFSdata"));
 //BA.debugLineNum = 112;BA.debugLine="aWOT.res_set(\"Content-Type\", \"text/plain\")";
b4r_main::_awot->res_set(be_ann79_4.wrap("Content-Type"),be_ann79_6.wrap("text/plain"));
 //BA.debugLineNum = 113;BA.debugLine="aWOT.res_set(\"Content-Encoding\",\"none\")";
b4r_main::_awot->res_set(be_ann80_4.wrap("Content-Encoding"),be_ann80_6.wrap("none"));
 //BA.debugLineNum = 114;BA.debugLine="aWOT.res_println(bc.StringFromBytes(GlobalStor";
b4r_main::_awot->res_println(b4r_main::_bc->StringFromBytes(b4r_main::_globalstore->_slot0 /*B4R::Array**/ ));
 //BA.debugLineNum = 115;BA.debugLine="aWOT.res_println(NumberFormat(lfs.TotalSize,0,";
b4r_main::_awot->res_println(B4R::__c->NumberFormat(b4r_main::_lfs->getTotalSize(),(Byte) (0),(Byte) (0)));
 //BA.debugLineNum = 116;BA.debugLine="aWOT.res_println(NumberFormat(lfs.UsedSize,0,0";
b4r_main::_awot->res_println(B4R::__c->NumberFormat(b4r_main::_lfs->getUsedSize(),(Byte) (0),(Byte) (0)));
 //BA.debugLineNum = 117;BA.debugLine="For Each f As File In lfs.ListFiles(bc.StringF";
B4R::Iterator* group7 = b4r_main::_lfs->ListFiles(b4r_main::_bc->StringFromBytes(b4r_main::_globalstore->_slot0 /*B4R::Array**/ ));
while (group7->MoveNext()) {
_f = (B4R::B4RFile*)B4R::Object::toPointer(group7->Get());
 //BA.debugLineNum = 118;BA.debugLine="browserFSload1(f)";
_browserfsload1(_f);
 }
;
 //BA.debugLineNum = 121;BA.debugLine="aWOT.res_sendStatus(200)";
b4r_main::_awot->res_sendStatus(200);
 //BA.debugLineNum = 122;BA.debugLine="aWOT.res_end";
b4r_main::_awot->res_end();
 //BA.debugLineNum = 123;BA.debugLine="If DebugF Then Log(\"stack FSload=\",StackBuffer";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(2,102,F("stack FSload="),4,B4R::__c->StackBufferUsage());};
 //BA.debugLineNum = 124;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_m7_filebrowser(){
const UInt cp = B4R::StackMemory::cp;
B4R::Object be_ann68_6;
B4R::Object be_ann70_6;
B4R::Object be_ann72_6;
B4R::Object be_ann74_6;
 //BA.debugLineNum = 87;BA.debugLine="Sub m7_filebrowser  '//case inlineC string";
 //BA.debugLineNum = 89;BA.debugLine="RunNative(\"gethtml\", 0)		'MAIN_page";
Common_RunNative(gethtml,be_ann68_6.wrapNumber((Long)0));
 //BA.debugLineNum = 90;BA.debugLine="aWOT.res_write1(text,text.length)";
b4r_main::_awot->res_write1(b4r_main::_text,(UInt) (b4r_main::_text->length));
 //BA.debugLineNum = 91;BA.debugLine="RunNative(\"gethtml\", 1)		'MAIN_page1";
Common_RunNative(gethtml,be_ann70_6.wrapNumber((Long)1));
 //BA.debugLineNum = 92;BA.debugLine="aWOT.res_write1(text,text.length)";
b4r_main::_awot->res_write1(b4r_main::_text,(UInt) (b4r_main::_text->length));
 //BA.debugLineNum = 93;BA.debugLine="RunNative(\"gethtml\", 2)		'MAIN_page2";
Common_RunNative(gethtml,be_ann72_6.wrapNumber((Long)2));
 //BA.debugLineNum = 94;BA.debugLine="aWOT.res_write1(text,text.length)";
b4r_main::_awot->res_write1(b4r_main::_text,(UInt) (b4r_main::_text->length));
 //BA.debugLineNum = 95;BA.debugLine="RunNative(\"gethtml\", 3)		'MAIN_page3";
Common_RunNative(gethtml,be_ann74_6.wrapNumber((Long)3));
 //BA.debugLineNum = 96;BA.debugLine="aWOT.res_write1(text,text.length)";
b4r_main::_awot->res_write1(b4r_main::_text,(UInt) (b4r_main::_text->length));
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_notfound(){
const UInt cp = B4R::StackMemory::cp;
B4R::B4RString be_ann362_12;
B4R::B4RString be_ann362_14;
B4R::B4RString be_ann362_16;
B4R::B4RString be_ann362_18;
B4R::B4RString be_ann362_20;
B4R::B4RString be_ann362_22;
B4R::B4RString be_ann362_24;
B4R::B4RString be_ann362_26;
B4R::B4RString* be_ann362_27e1[8];
B4R::Array be_ann362_27e2;
B4R::Array* _meth_type = NULL;
 //BA.debugLineNum = 452;BA.debugLine="Sub notfound()";
 //BA.debugLineNum = 453;BA.debugLine="Dim meth_type() As String = Array As String(\"UNKN";
_meth_type = be_ann362_27e2.create(be_ann362_27e1,8,100,be_ann362_12.wrap("UNKNOWN"),be_ann362_14.wrap("GET"),be_ann362_16.wrap("HEAD"),be_ann362_18.wrap("POST"),be_ann362_20.wrap("PUT"),be_ann362_22.wrap("DELETE"),be_ann362_24.wrap("OPTIONS"),be_ann362_26.wrap("ALL"));
 //BA.debugLineNum = 454;BA.debugLine="Log(\"Middleware not found - Call Back 404\")";
B4R::Common::LogHelper(1,102,F("Middleware not found - Call Back 404"));
 //BA.debugLineNum = 455;BA.debugLine="Log(\"method = \",meth_type(aWOT.req_method))";
B4R::Common::LogHelper(2,102,F("method = "),101,((B4R::B4RString**)_meth_type->getData((UInt) (b4r_main::_awot->req_method())))[B4R::Array::staticIndex]->data);
 //BA.debugLineNum = 456;BA.debugLine="Log(\"path = \",aWOT.req_path)";
B4R::Common::LogHelper(2,102,F("path = "),101,b4r_main::_awot->req_path()->data);
 //BA.debugLineNum = 459;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_process(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 59;BA.debugLine="Sub process()";
 //BA.debugLineNum = 60;BA.debugLine="aWOT.process";
b4r_main::_awot->process();
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}

void b4r_main::initializeProcessGlobals() {
     B4R::StackMemory::buffer = (byte*)malloc(STACK_BUFFER_SIZE);
     b4r_main::_process_globals();
b4r_globalstore::_process_globals();

   
}
void b4r_main::_process_globals(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 9;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 10;BA.debugLine="Public P_buff() As Byte";
b4r_main::_p_buff =be_gann1_4e2.wrap(be_gann1_4e1,0);
 //BA.debugLineNum = 11;BA.debugLine="Public text() As Byte";
b4r_main::_text =be_gann2_4e2.wrap(be_gann2_4e1,0);
 //BA.debugLineNum = 12;BA.debugLine="Public Serial1 As Serial";
b4r_main::_serial1 = &be_gann3_3;
 //BA.debugLineNum = 13;BA.debugLine="Private wifi As ESP8266WiFi";
b4r_main::_wifi = &be_gann4_3;
 //BA.debugLineNum = 14;BA.debugLine="Private bc As ByteConverter";
b4r_main::_bc = &be_gann5_3;
 //BA.debugLineNum = 15;BA.debugLine="Private lfs As LittleFS";
b4r_main::_lfs = &be_gann6_3;
 //BA.debugLineNum = 16;BA.debugLine="Private aWOT As aWOT";
b4r_main::_awot = &be_gann7_3;
 //BA.debugLineNum = 17;BA.debugLine="Dim buff(256) As Byte";
b4r_main::_buff =be_gann8_4e2.wrap(be_gann8_4e1,256);
 //BA.debugLineNum = 18;BA.debugLine="Dim Debug As Boolean = True";
b4r_main::_debug = Common_True;
 //BA.debugLineNum = 19;BA.debugLine="Dim DebugF As Boolean = False";
b4r_main::_debugf = Common_False;
 //BA.debugLineNum = 20;BA.debugLine="Dim traces As Boolean = True";
b4r_main::_traces = Common_True;
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
}
void b4r_main::_writestream(UInt _nbw){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 275;BA.debugLine="Sub writestream(nbW As UInt)";
 //BA.debugLineNum = 276;BA.debugLine="If aWOT.req_availableForWrite < buff.Length Th";
if (b4r_main::_awot->req_availableForWrite()<b4r_main::_buff->length) { 
 //BA.debugLineNum = 277;BA.debugLine="If DebugF Then Log(\"=> flush\")";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(1,102,F("=> flush"));};
 //BA.debugLineNum = 278;BA.debugLine="aWOT.req_flush";
b4r_main::_awot->req_flush();
 };
 //BA.debugLineNum = 280;BA.debugLine="If DebugF Then Log(\"written to aWOT stream:\",a";
if (b4r_main::_debugf) { 
B4R::Common::LogHelper(2,102,F("written to aWOT stream:"),4,b4r_main::_awot->res_write1(b4r_main::_buff,_nbw));}
else {
b4r_main::_awot->res_write1(b4r_main::_buff,_nbw);};
 //BA.debugLineNum = 281;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
