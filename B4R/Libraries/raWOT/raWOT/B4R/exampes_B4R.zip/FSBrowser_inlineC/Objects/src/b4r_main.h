
#ifndef b4r_main_h
#define b4r_main_h
class b4r_globalstore;

class b4r_main {
public:

static void initializeProcessGlobals();
static void _appstart();
static Byte _awotreq_read(ULong _fsize,Byte _tag);
static void _browserfsload1(B4R::B4RFile* _f);
static UInt _cutheader();
static void _finally();
static void _getdatafiles(B4R::B4RString* _fullnam,B4R::B4RString* _c_type,B4R::B4RString* _c_encoding);
static B4R::B4RString* _getext(B4R::Array* _filename);
static B4R::B4RString* _getfullnam(B4R::Array* _filename);
static void _m0_traces();
static void _m21_dirclose(B4R::B4RString* _nam1);
static void _m21_dircreate(B4R::B4RString* _nam1);
static void _m21_dirdelete(B4R::B4RString* _nam1);
static void _m21_diropen(B4R::B4RString* _nam1);
static void _m21_filebrowser_action();
static void _m21_filedelete(B4R::B4RString* _nam1);
static void _m21_filerename(B4R::B4RString* _nam1,B4R::B4RString* _nam2);
static void _m21_format();
static void _m22_fileupload();
static void _m23_file_download(B4R::B4RString* _filename);
static void _m23_filedownload();
static void _m30_browserfsload();
static void _m7_filebrowser();
static void _notfound();
static void _process();
static void _process_globals();
static B4R::Array* _p_buff;
static B4R::Array* _text;
static B4R::Serial* _serial1;
static B4R::B4RESPWiFi* _wifi;
static B4R::ByteConverter* _bc;
static B4R::B4RLittleFS* _lfs;
static B4R::B4RaWOT* _awot;
static B4R::Array* _buff;
static bool _debug;
static bool _debugf;
static bool _traces;
static b4r_globalstore* _globalstore;
static void _writestream(UInt _nbw);
};

#endif