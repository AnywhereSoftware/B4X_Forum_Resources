#include "B4RDefines.h"
namespace B4R {
	void B4RDHTESP::Setup11(Byte Pin) {
		Dht.setup(Pin, DHTesp::DHT11);
	}
	void B4RDHTESP::Setup22(Byte Pin) {
		Dht.setup(Pin, DHTesp::DHT22);
	}
	float B4RDHTESP::GetHumidity(){
		return Dht.getHumidity();
	}
	float B4RDHTESP::GetTemperature(){
		return Dht.getTemperature();
	}
}