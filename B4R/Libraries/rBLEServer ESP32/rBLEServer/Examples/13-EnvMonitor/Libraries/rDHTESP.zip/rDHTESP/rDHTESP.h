//rDHTesp for DHT11 & DHT22 sensors
//B4R Library (partly) wrapped from project https://github.com/beegee-tokyo/arduino-DHTesp. Thanks to the author.
//Changelog
//20190927: v1.01
#pragma once
#include "B4RDefines.h"
#include "DHTesp.h"
namespace B4R {
	//~Version: 1.01
	//~shortname: DHTESP
	//~Author: Robert W.B. Linn
	//ESP DHT11 DHT22 lib
	class B4RDHTESP {
		private:
			//Declare object from DHTesp.h
			DHTesp Dht;
		public:
			/**
			*Setup DHT11.
			*/
			void Setup11(Byte Pin);
			/**
			*Setup DHT22.
			*/
			void Setup22(Byte Pin);
			/**
			*Read Humidity as Percentage from DHT.
			*Returns nan if there was a failure.
			*/
			float GetHumidity();
			/**
			*Read temperature from DHT (Celsius).
			*Returns nan if there was a failure.
			*/
			float GetTemperature();	
	};
}