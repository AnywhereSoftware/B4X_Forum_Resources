Changelog rDHTESP

20190927 (v1.01)
* UPD: Corrected tooltip function Initialize.

20190913 (v1.00)
* NEW: First version.
