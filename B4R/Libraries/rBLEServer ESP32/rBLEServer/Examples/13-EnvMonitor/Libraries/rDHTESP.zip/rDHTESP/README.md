# rDHTESP
rDHTESP is an open source B4R library for the DHT11 &amp; DHT22 sensors connected to an ESP microcontroller.
Read the temperature (C) & humidity (%RH) from the connected DHT sensor.

This B4R Library
* is written in C++ (using the Arduino IDE 1.8.9 and the B4Rh2xml tool).
* is (partly) wrapped based on the project DHTesp library (see credits).
* has been tested with an ESP32 and ESP8266ESP-WROOM-32, NodeMCU v1.0, DHT22 (with 3 pins & internal resistor).
* has been created for **personal use**  only.

[B4R](https://www.b4x.com/b4r.html) development tool for native Arduino and ESP programs by [Anywhere Software](https://www.b4x.com).

## Files
* rDHTESP.zip archive contains the library and sample projects.

## Install
From the zip archive, copy the content of the library folder, to the B4R additional libraries folder keeping the folder structure.

## Wiring
Tested with the two boards:

    DHT22=ESP32
		GND(-)=GND
		Signal(out)=IO4
		VCC(+)=5V
		
		DHT22=ESP8266 NodeMCU v1.0
		GND(-)=GND
		Signal(out)=D2 (GPIO4)
		VCC(+)=3V

## Object
Declare the Object referring to the library.
    
		Private dhtEsp As DHTESP
    Private dhtPinNumber As UInt = 0x04

## Library Functions

### dhtEsp.Setup22(dhtPinNumber)
Initialize the sensor with pinnumber.

### dhtEsp.GetTemperature
Get the temperature in C.

### dhtEsp.GetHumidity
Get the humidity in %RH.

## B4R Example
Hardware: ESP8266 NodeMCU 1.0.
```
#Region Project Attributes
	#AutoFlushLogs: True
	#CheckArrayBounds: True
	#StackBufferSize: 600
#End Region

Sub Process_Globals
	'AppID
	Private APPID As String = "DHT22ESP"
	'Serial
	Public serialLine As Serial
	Private serialLineBaudRate As ULong = 115200
	'Sensor
	Private dhtEsp As DHTESP						
	Private dhtPinNumber As UInt = 0x04
	Private humidityValue As Float					
	Private temperatureValue As Float				
	'Timer
	Private timerSampling As Timer          		
	Private timerSamplingInterval As ULong = 5
End Sub

Private Sub AppStart
	serialLine.Initialize(serialLineBaudRate)
	Log("AppStart - ",APPID)
	dhtEsp.Setup22(dhtPinNumber)
	timerSampling.Initialize("TimerSampling_Tick", timerSamplingInterval * 1000)
	timerSampling.Enabled = True
End Sub

'Handle the timer ticks
Private Sub TimerSampling_Tick
	temperatureValue = dhtEsp.GetTemperature
	humidityValue = dhtEsp.GetHumidity
	Log("Temperature =", NumberFormat(temperatureValue,0,2) , " C", ", Humidity = ", NumberFormat(humidityValue,0,2), " %RH")
	'Temperature =21.70 C, Humidity = 74.30 %RH
	'Temperature =21.60 C, Humidity = 74.40 %RH
End Sub
```

## Credits
* Anywhere Software for providing B4R (and of course the whole B4X suite) [Info](https://www.b4x.com/)
• Authors of the library DHTesp [Info](https://github.com/beegee-tokyo/arduino-DHTesp)
* Friends-of-Fritzing foundation for fritzing [Info](https://fritzing.org)

## Licence
GNU General Public License v3.0.
