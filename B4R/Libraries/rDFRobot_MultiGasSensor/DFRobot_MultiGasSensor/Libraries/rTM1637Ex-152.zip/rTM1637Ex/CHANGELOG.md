# CHANGELOG B4R Library rTM1637Ex

## v1.52 (Build 20251006)
* FIX: ShowText truncate if number of characters exceeds 4.

### v1.51 (Build 20220409)
* UPD: Removed PROGMEM from the header declaration for the character font tables for use on ESP8266 (avoid section attribute error).

### v1.50 (Build 20210525)
* NEW: ShowText - Display up to 4 characters or symbols.
* NEW: Font - AscII or Siekoo.
* NEW: GetChar - Select char as byte.
* NEW: Examples - Show text with AscII or Siekoo font, SetSegments own symbols.
* UPD: Various minor improvements.

### v1.00 (Build 20210217)
* NEW: Published on Anywhere Software B4R Forum Libraries.
